package com.fasterxml.jackson.jaxrs.json;

import javax.ws.rs.ext.Provider;

/**
 * @deprecated Since 2.2 use {@link com.fasterxml.jackson.jaxrs.base.JsonMappingExceptionMapper} instead.
 */
@Deprecated
@Provider
public class JsonMappingExceptionMapper extends com.fasterxml.jackson.jaxrs.base.JsonMappingExceptionMapper { }
