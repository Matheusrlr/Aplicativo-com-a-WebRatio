package com.fasterxml.jackson.jaxrs.json;

import javax.ws.rs.ext.Provider;

/**
 * @deprecated Use {@link com.fasterxml.jackson.jaxrs.base.JsonParseExceptionMapper} instead.
 */
@Deprecated
@Provider
public class JsonParseExceptionMapper extends com.fasterxml.jackson.jaxrs.base.JsonParseExceptionMapper { }
