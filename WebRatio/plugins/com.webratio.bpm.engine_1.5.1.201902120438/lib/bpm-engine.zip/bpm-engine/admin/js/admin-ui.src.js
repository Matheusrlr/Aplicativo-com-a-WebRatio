(function(GLOBAL,undefined){

;(function(){"use strict";



//== __global_defines.js ======================================================

/**
 * @define {boolean}
 */
var DEBUG = true;

/**
 * @define {string}
 */
var FILE_NAME = 'admin-ui.src.js';

/**
 * @define {string}
 */
var FILE_VERSION = '1.0.0.201603242107';




//== __global_export.js =======================================================

/*
 * Exporting
 */

/**
 * Exposes an unobfuscated global namespace path for the given object. Note that fields of the exported object will be obfuscated,
 * unless they are exported in turn via this function or goog.exportProperty
 * <p>
 * Also handy for making public items that are defined in anonymous closures.
 * 
 * @internal
 * @param {string} publicPath Unobfuscated name to export.
 * @param {*} object Value the name should point to.
 * @param {Object=} objectToExportTo Object to add the path to; default is <code>GLOBAL</code>.
 */
var exportSymbol = function(publicPath, object, objectToExportTo) {
    _exportPath(publicPath, object, objectToExportTo);
};

/**
 * Builds an object structure for the provided namespace path, ensuring that names that already exist are not overwritten. <br>
 * For example: "a.b.c" -> a = {};a.b={};a.b.c={};
 * 
 * @private
 * @param {string} name Name of the object that this file defines.
 * @param {*=} object Value to expose at the end of the path.
 * @param {Object=} objectToExportTo Object to add the path to; default is <code>GLOBAL</code>.
 */
var _exportPath = function(name, object, objectToExportTo) {
    var parts = name.split(".");
    var cur = objectToExportTo || GLOBAL;

    /*
     * Certain browsers cannot parse code in the form for((a in b); c;); This pattern is produced by the Closure Compiler when it
     * collapses the statement above into the conditional loop below. To prevent this from happening, use a for-loop and reserve the
     * init logic as below.
     */
    for (var part; parts.length && (part = parts.shift());) {
        var curPrev = cur;
        if (!parts.length && object !== undefined) {
            /* Last part and we have an object; use it */
            cur[part] = object;
        } else if (cur[part]) {
            cur = cur[part];
        } else {
            cur = cur[part] = {};
        }
    }
};

/**
 * Exports a property unobfuscated into the object's namespace.
 * 
 * @internal
 * @param {Object} object Object whose static property is being exported.
 * @param {string} publicName Unobfuscated name to export.
 * @param {*} symbol Value the name should point to.
 */
var exportProperty = function(object, publicName, symbol) {
    object[publicName] = symbol;
};




//== __global_tools.js ========================================================

/*
 * Special values and functions
 */

/**
 * A function that does not return or do anything.
 * 
 * @internal
 */
var EMPTY_FUNCTION = function() {};

/*
 * OO constructs
 */

/**
 * Placeholder function for use in interfaces and abstract classes to implement abstract methods.
 * <p>
 * The returned function always throws an error, so that if it is not overridden by an actual implementation, a runtime error will
 * result.
 * 
 * @internal
 * @const
 * @type {!Function}
 * @throws {Error} Always, since this function should never be called in a correct program.
 */
var ABSTRACT_METHOD = function() {
    throw new Error("Unimplemented abstract method");
};

/**
 * Constructs a new object having a specific object as prototype.
 * <p>
 * This function enables creating objects with a specific prototype chain without having to create an ad-hoc constructor function.
 * 
 * @internal
 * @param {Object} proto Object to use as prototype for the new object or <code>null</code> for using the the built-in {@link Object}
 *            prototype.
 * @param {Object=} properties Own properties to set on the new object. If not specified, nothing is set.
 * @return {!Object} Created object.
 */
var newObject = function(proto, properties) {
    var o;
    if (proto) {
        /** @constructor */
        var ctor = function() {};
        ctor.prototype = proto;
        o = new ctor();
    } else {
        o = {};
    }
    if (properties) {
        for (var p in properties) {
            if (properties.hasOwnProperty(p)) {
                o[p] = properties[p];
            }
        }
    }
    return o;
};

/**
 * @private
 * @param {!Function} derived
 * @param {!Function} base
 */
var _extendConstructor = function(derived, base) {
    derived._super = base.prototype;
    derived.prototype = newObject(base.prototype);
    derived.prototype["constructor"] = derived;
};

/**
 * Implements inheritance by having a constructor extend a base constructor.
 * <p>
 * Instances of the derived constructor will successfully pass an <code>instanceof</code> test against both their constructor and all
 * super-constructors. In addition, all constructor instances will inherit prototype properties of all super-constructors.
 * 
 * @internal
 * @param {function(new:Object)} derived Derived (more specific) constructor function.
 * @param {function(new:Object)} base Base (more generic) constructor function.
 */
var extendConstructor = _extendConstructor;

/**
 * Implements inheritance by having a function prototype extend the prototype of another function.
 * 
 * @internal
 * @param {?} derived Derived (more specific) function.
 * @param {?} base Base (more generic) function.
 */
var extendFunctionPrototype = (/** @type {function(?,?)} */
(_extendConstructor));

/**
 * @internal
 * @template T
 * @param {string} name
 * @param {function(new:Error,string=)=} base
 * @param {T=} constructor
 * @return {T}
 */
var makeCustomErrorConstructor = function(name, base, constructor) {
    base = base || GLOBAL["Error"];

    /**
     * @constructor
     * @extends Error
     */
    var ctor = function() {
        var tmp = null;
        this._super = function() {
            tmp = base.apply(this, arguments);
        }.bind(this);
        if (constructor) {
            constructor.apply(this, arguments);
        }
        if (!tmp) {
            this._super.apply(this, arguments);
        }
        delete this._super;
        this.name = name;
        this.message = tmp.message || name;
        if (typeof Error["captureStackTrace"] === "function") {
            Error["captureStackTrace"](tmp, ctor);
        }
        if (tmp.stack !== undefined) {
            this.stack = tmp.stack;
        }
    };
    _extendConstructor(ctor, base);

    return ctor;
};




//== ui/AppRun.js =============================================================

var ui = {};

/**
 * @package
 * @const
 */
ui.AppRun = {};

/**
 * @ngInject
 * @param {!angular.$route} $route
 * @param {!angular.Scope} $rootScope
 */
ui.AppRun.startRouterInternalPathMonitor = function($route, $rootScope) {
    ui.Router.startMonitoringInternalPath($route, $rootScope);
};




//== ui/BackEndService.js =====================================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.$http} $http
 * @param {!ui.ConfigService} uiConfig
 * @param {!angular.$log} $log
 */
ui.BackEndService = function($http, uiConfig, $log) {

    /** @private */
    this._$http = $http;

    /** @private */
    this._$log = $log;

    /** @private */
    this._baseUrl = this._computeBaseUrl(uiConfig);

    /**
     * @private
     * @type {rest.RestClient}
     */
    this._restClient = rest.RestClient.createNew(this._baseUrl).httpClient(new rest.http.AngularHttpClient($http));

    /**
     * @private
     * @type {?ui.AuthService}
     */
    this._authService = null;
}

/**
 * @private
 * @param {!ui.ConfigService} uiConfig
 * @return {string}
 */
ui.BackEndService.prototype._computeBaseUrl = function(uiConfig) {
    var baseUrl = uiConfig.get("backEndBaseUrl");
    return baseUrl;
};

/**
 * @param {!ui.AuthService} authService
 */
ui.BackEndService.prototype.initAuthService = function(authService) {
    if (this._authService) {
        throw new Error("Auth service already initialized");
    }
    this._authService = authService;
};

/**
 * @private
 * @return {!ui.AuthService}
 */
ui.BackEndService.prototype._retrieveAuthService = function() {
    if (!this._authService) {
        throw new Error("Auth service not initialized");
    }
    return this._authService;
}

/*
 * Users
 */

/**
 * @param {string} username
 * @param {string} password
 * @return {!Promise<{user:{oid:number, token:string}, username:string}>}
 */
ui.BackEndService.prototype.login = function(username, password) {
    return this._makeRequest("POST", "users/login", null, {
        noAuthentication: true,
        data: JSON.stringify({
            "username": username,
            "password": password
        }),
        transformer: function(data) {
            return {
                user: {
                    oid: rest.data.extractNumberValue(data, "oid"),
                    token: rest.data.extractStringValue(data, "token"),
                    username: rest.data.extractStringValue(data, "username")
                }
            };
        }
    });
}

/**
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listUsers = function(query) {
    return this._makeRequest("GET", "users", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {number} userId
 * @return {!Promise<!Object>}
 */
ui.BackEndService.prototype.retrieveUser = function(userId) {
    return this._makeRequest("GET", "users/" + encodeURIComponent(String(userId)), null, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data)[0];
        }
    });
}

/**
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listRoles = function(query) {
    return this._makeRequest("GET", "roles", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {number} userId
 * @param {string} oldPassword
 * @param {string} newPassword
 * @return {!Promise<!Array<!Object>>}
 */
ui.BackEndService.prototype.changeUserPassword = function(userId, oldPassword, newPassword) {
    var path;
    if (userId === this._retrieveAuthService().retrieveUserOid()) {
        path = "users/me";
    } else {
        path = "users/" + encodeURIComponent(String(userId));
    }
    return this._makeRequest("PUT", path, null, {
        data: JSON.stringify({
            "oldPassword": oldPassword,
            "newPassword": newPassword
        }),
        transformer: function(data) {
            return {
                oid: rest.data.extractNumberValue(data, "oid")
            }
        }
    });
}

/**
 * @param {number} userId
 * @param {!Object} data
 * @return {!Promise<Object>}
 */
ui.BackEndService.prototype.updateUser = function(userId, data) {
    var path;
    if (userId === this._retrieveAuthService().retrieveUserOid()) {
        path = "users/me";
    } else {
        path = "users/" + encodeURIComponent(String(userId));
    }
    return this._makeRequest("PUT", path, null, {
        data: JSON.stringify({
            "data": data
        })
    });
}

/**
 * @param {!string} username
 * @param {!string} password
 * @param {?Object} data
 * @return {!Promise<Object>}
 */
ui.BackEndService.prototype.createUser = function(username, password, data) {
    return this._makeRequest("POST", "users/register", null, {
        data: JSON.stringify({
            "username": username,
            "password": password,
            "data": data
        }),
        transformer: function(data) {
            return {
                oid: rest.data.extractNumberValue(data, "oid"),
            };
        }
    });
}

/**
 * @param {number} userId
 * @return {!Promise}
 */
ui.BackEndService.prototype.deleteUser = function(userId) {
    return this._makeRequest("DELETE", "users/" + encodeURIComponent(String(userId)), null, {});
}

/*
 * Processes
 */

/**
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listProcesses = function(query) {
    return this._makeRequest("GET", "processes", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {number} processId
 * @return {!Promise<!Object>}
 */
ui.BackEndService.prototype.retrieveProcess = function(processId) {
    return this._makeRequest("GET", "processes/" + encodeURIComponent(String(processId)), null, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data)[0];
        }
    });
}

/**
 * @param {number} processId
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listProcessNotes = function(processId, query) {
    return this._makeRequest("GET", "processes/" + encodeURIComponent(String(processId)) + "/notes", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {number} processId
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listProcessAttachments = function(processId, query) {
    return this._makeRequest("GET", "processes/" + encodeURIComponent(String(processId)) + "/attachments", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {number} processId
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listProcessTasks = function(processId, query) {
    return this._makeRequest("GET", "processes/" + encodeURIComponent(String(processId)) + "/tasks", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {string} processDefinitionId
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.retrieveProcessDefinitions = function(processDefinitionId, query) {
    return this._makeRequest("GET", "process-definitions/" + encodeURIComponent(String(processDefinitionId)), query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {number} processId
 * @return {!Promise<!string>}
 */
ui.BackEndService.prototype.retrieveProcessDiagramId = function(processId) {
    return this._makeRequest("GET", "processes/" + encodeURIComponent(String(processId)) + "/diagram", null, {
        transformer: function(data) {
            return data["diagramId"];
        }
    });
}

/**
 * @param {number} processId
 * @return {!Promise<!string>}
 */
ui.BackEndService.prototype.retrieveHistoricProcessDiagramId = function(processId) {
    return this._makeRequest("GET", "historic-processes/" + encodeURIComponent(String(processId)) + "/diagram", null, {
        transformer: function(data) {
            return data["diagramId"];
        }
    });
}

/**
 * @param {string} processDefinitionId
 * @return {!Promise<!string>}
 */
ui.BackEndService.prototype.retrieveProcessDefinitionDiagramId = function(processDefinitionId) {
    return this._makeRequest("GET", "process-definitions/" + encodeURIComponent(String(processDefinitionId)) + "/diagram", null, {
        transformer: function(data) {
            return data["diagramId"];
        }
    });
}

/**
 * @param {string} fileId
 * @return {!Promise<!Blob>}
 */
ui.BackEndService.prototype.downloadFile = function(fileId) {
    return this._makeRequest("GET", "files/download/" + fileId, null, {
        responseType: "arraybuffer",
        transformer: function(data, headers) {
            return new Blob([ data ], {
                type: headers["content-type"]
            });
        }
    });
}

/**
 * @param {!number} processId
 * @param {!string} messageDefinitionId
 * @param {?Array<Object>} parameters
 * @return {!Promise<Object>}
 */
ui.BackEndService.prototype.sendMessage = function(processId, messageDefinitionId, parameters) {
    return this._makeRequest("POST", "events/message", null, {
        data: JSON.stringify({
            "processes": [ processId ],
            "parameters": parameters,
            "definitionId": messageDefinitionId
        }),
    });
}

/**
 * @param {!string} messageDefinitionId
 * @param {?Array<Object>} parameters
 * @return {!Promise<Object>}
 */
ui.BackEndService.prototype.sendMessageNoProcess = function(messageDefinitionId, parameters) {
    return this._makeRequest("POST", "events/message", null, {
        data: JSON.stringify({
            "parameters": parameters,
            "definitionId": messageDefinitionId
        }),
    });
}

/**
 * @param {!string} processName
 * @param {!string} eventName
 * @param {?Array<Object>} parameters
 * @return {!Promise<Object>}
 */
ui.BackEndService.prototype.startProcess = function(processName, eventName, parameters) {
    return this._makeRequest("POST", "processes", null, {
        data: JSON.stringify({
            "processName": processName,
            "parameters": parameters,
            "eventId": eventName
        }),
    });
}

/**
 * @param {number} processId
 * @param {!string} action
 * @return {!Promise<Object>}
 */
ui.BackEndService.prototype.performedProcessAction = function(processId, action) {
    return this._makeRequest("PUT", "processes/" + encodeURIComponent(String(processId)), null, {
        data: JSON.stringify({
            "action": action
        }),
    });
}// TODO unit test!

/*
 * Definitions
 */

/**
 * @param {string} processDefinitionId
 * @return {!Promise<!Object>}
 */
ui.BackEndService.prototype.retrieveProcessDefinition = function(processDefinitionId) {
    return this._makeRequest("GET", "process-definitions/" + encodeURIComponent(String(processDefinitionId)), null, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data)[0];
        }
    });
}

/**
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listProcessDefinitions = function(query) {
    return this._makeRequest("GET", "process-definitions", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listProcessArchives = function(query) {
    return this._makeRequest("GET", "process-archives", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {File} file
 * @return {!Promise<!string>}
 */
ui.BackEndService.prototype.uploadProcessArchiveFile = function(file) {
    var formData = new FormData();
    formData.append("file", file);
    return this._makeRequest("POST", "process-archives", null, {
        data: formData,
        headers: {
            "Content-Type": undefined
        },
        transformer: function(data) {
            return data["archiveId"];
        }
    });
}

/**
 * @param {number} archiveId
 * @return {!Promise}
 */
ui.BackEndService.prototype.deleteProcessArchive = function(archiveId) {
    return this._makeRequest("DELETE", "process-archives/" + encodeURIComponent(String(archiveId)), null, {});
}

/**
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listHistoricProcesses = function(query) {
    return this._makeRequest("GET", "historic-processes", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/*
 * Tasks
 */

/**
 * @param {number} taskId
 * @param {string} action
 * @return {!Promise<Object>}
 */
ui.BackEndService.prototype.updateTaskAction = function(taskId, action) {
    return this._makeRequest("PUT", "tasks/" + encodeURIComponent(String(taskId)), null, {
        data: JSON.stringify({
            "action": action
        })
    });
}

/**
 * @param {number} taskId
 * @param {number} userId
 * @return {!Promise<Object>}
 */
ui.BackEndService.prototype.updateTaskUser = function(taskId, userId) {
    return this._makeRequest("PUT", "tasks/" + encodeURIComponent(String(taskId)), null, {
        data: JSON.stringify({
            "action": "ASSIGN",
            "user": userId
        })
    });
}

/**
 * @param {number} taskId
 * @param {string} role
 * @return {!Promise<Object>}
 */
ui.BackEndService.prototype.updateTaskRole = function(taskId, role) {
    return this._makeRequest("PUT", "tasks/" + encodeURIComponent(String(taskId)), null, {
        data: JSON.stringify({
            "action": "ASSIGN",
            "role": role
        })
    });
}

/**
 * @param {number} taskId
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.retrieveTaskCandidateUsers = function(taskId, query) {
    return this._makeRequest("GET", "tasks/" + encodeURIComponent(String(taskId)) + "/candidate-users", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data, "users");
        }
    });
}

/**
 * @param {number} taskId
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.retrieveTaskCandidateRoles = function(taskId, query) {
    return this._makeRequest("GET", "tasks/" + encodeURIComponent(String(taskId)) + "/candidate-roles", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data, "roles");
        }
    });
}

/**
 * @param {number} historicProcessId
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listHistoricProcessTasks = function(historicProcessId, query) {
    return this._makeRequest("GET", "historic-processes/" + encodeURIComponent(String(historicProcessId)) + "/tasks", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {number} historicProcessId
 * @return {!Promise<!Object>}
 */
ui.BackEndService.prototype.retrieveHistoricProcess = function(historicProcessId) {
    return this._makeRequest("GET", "historic-processes/" + encodeURIComponent(String(historicProcessId)), null, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data)[0];
        }
    });
}

/**
 * @param {number} historicProcessId
 * @return {!Promise<!Object>}
 */
ui.BackEndService.prototype.listHistoricProcessNotes = function(historicProcessId, query) {
    return this._makeRequest("GET", "historic-processes/" + encodeURIComponent(String(historicProcessId)) + "/notes", null, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/**
 * @param {number} processId
 * @param {null|rest.data.Query} query
 * @return {!Promise<!rest.data.ResultSet<!Object>>}
 */
ui.BackEndService.prototype.listHistoricProcessAttachments = function(processId, query) {
    return this._makeRequest("GET", "historic-processes/" + encodeURIComponent(String(processId)) + "/attachments", query, {
        transformer: function(data) {
            return ui.BackEndService._extractResultSet(data);
        }
    });
}

/*
 * Common tools
 */

/**
 * @private
 * @param {!rest.data.Query|undefined} query
 * @return {!Object|undefined}
 */
ui.BackEndService._serializeQuery = function(query) {
    if (!query) {
        return undefined;
    }
    var params = query.writeToObject({});
    if (params["sort"]) {
        params["sort"] = params["sort"].join(",");
    }
    return params;
};

/**
 * @private
 * @template T
 * @param {!Object} object
 * @param {!string=} propertyName
 * @return {!rest.data.ResultSet<T>}
 */
ui.BackEndService._extractResultSet = function(object, propertyName) {
    var key = (propertyName ? propertyName : "data");
    var data = object[key];
    if (data === undefined || data === null) {
        data = [];
    }
    if (!Array.isArray(data)) {
        throw new Error("Missing or invalid array value for '" + key + "'");
    }
    var metadata = rest.data.Metadata.readFromObject(object);
    return new rest.data.ResultSet(data, metadata, 200);
};

/**
 * @private
 * @template T
 * @param {string} method
 * @param {string} path
 * @param {null|rest.data.Query} query
 * @param {{ noAuthentication:(boolean|undefined), headers:(!Object<string,*>|undefined), params:(!Object<string,*>|undefined),
 *            data:(!Object|string|undefined), errors:(!Object<number,function(new:Error,string)>|*|undefined),
 *            validator:(function(?):boolean|undefined), transformer:(function(?,!Object<string,string>):T|undefined),
 *            responseType:(string|undefined) }} options
 * @return {!Promise<T>}
 */
ui.BackEndService.prototype._makeRequest = function(method, path, query, options) {
    var log = this._$log;
    if (DEBUG) {
        log.debug("Invoking " + method + path);
    }

    /* Prepare the request configuration */
    var extras = {}
    if (options.headers) {
        extras.headers = options.headers;
    }
    if (options.responseType) {
        extras["responseType"] = options.responseType;
    }
    this._restClient.resource(path).authorized(!options.noAuthentication).query(query).extras(extras);
    if (!options.noAuthentication) {
        this._restClient.authorizationToken(this._retrieveAuthService().retrieveToken());
    }
    var promise = null;

    if ("GET" === method) {
        promise = this._restClient.get();
    } else if ("POST" === method) {
        promise = this._restClient.post(options.data);
    } else if ("PUT" === method) {
        promise = this._restClient.put(options.data);
    } else if ("DELETE" === method) {
        promise = this._restClient.del();
    } else {
        var errorResult = null;
        throw new errorResult("Unsupported request method " + method);
    }

    /* Function for handling the response */
    function handleResponse(response) {
        if (DEBUG) {
            log.debug("Response " + response);
        }
        var data = response.data;
        var statusCode = response.status;

        /* Set an error message on request failure or on receiving invalid data */
        var errorMessage = null;
        if (statusCode < 200 || statusCode >= 400) {
            errorMessage = ((data && data["error-message"]) || response.statusText || "Network error (status " + statusCode + ")");
        } else if (options.validator && !options.validator(data)) {
            errorMessage = "Received invalid response from back-end, " + Object.prototype.toString.call(data);
        }

        /* If there was a problem, return an appropriate error object or throw an appropriate error */
        if (errorMessage) {
            var errorResult = (options.errors && options.errors[statusCode]);
            if (errorResult === undefined) {
                errorResult = Error;
            }
            if (typeof errorResult !== "function") {
                return errorResult;
            }
            throw new errorResult(errorMessage);
        }

        /* Transform the result data */
        if (options.transformer) {
            data = options.transformer(data, response.headers());
        }

        return data;
    }

    return promise.then(handleResponse, handleResponse);
}




//== ui/cmp/activityIndicator.js ==============================================

ui.cmp = {};

/**
 * @ngInject
 * @param {!ui.ActivityService} uiActivity
 * @return {!angular.Directive}
 */
ui.cmp.activityIndicator = function(uiActivity) {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "EA",
        scope: true,

        /**
         * @param {!angular.Scope} scope
         * @param {!angular.JQLite} element
         * @param {!angular.Attributes} attrs
         */
        link: function(scope, element, attrs) {

            function refresh() {
                scope["active"] = uiActivity.isActivityRunning();
                ui.applyScope(scope);
            }

            scope.$on("uiActivityStarted", refresh);
            scope.$on("uiActivityStopped", refresh);
            refresh();
        }
    }));
};



//== ui/cmp/blobDirective.js ==================================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.blobDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",
        scope: true,

        /**
         * @param {!angular.Scope} scope
         * @param {!angular.JQLite} element
         * @param {!angular.Attributes} attrs
         */
        link: function(scope, element, attrs) {
            scope.$watch(attrs["uiBlob"], function(newValue, oldValue) {
                if (scope["blob"]) {
                    URL.revokeObjectURL(scope["blob"]["url"]);
                }
                var url = URL.createObjectURL(newValue);
                scope["blob"] = {
                    "url": url
                };
            });
            scope.$on("$destroy", function() {
                if (scope["blob"]) {
                    URL.revokeObjectURL(scope["blob"]["url"]);
                }
            });
        }
    }));
};



//== ui/cmp/errorMessageDirective.js ==========================================

/**
 * @ngInject
 * @param {!angular.$animate} $animate
 * @return {!angular.Directive}
 */
ui.cmp.errorMessageDirective = function($animate) {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",

        /**
         * @param {!angular.Scope} scope
         * @param {!angular.JQLite} element
         * @param {!angular.Attributes} attrs
         */
        link: function(scope, element, attrs) {
            var m = /^(.+?)(?:\s*#\s*(\S+))?$/.exec(attrs["uiErrorMessage"]);
            if (!m) {
                throw new Error("Invalid error message reference expression");
            }
            var ngModelRef = m[1];
            var validatorName = (m[2] || null);

            /* Build the expression to detect invalidity */
            var expression = "" + ngModelRef + ".$dirty && " + ngModelRef;
            if (validatorName) {
                expression += ".$error." + validatorName;
            } else {
                expression += ".$invalid";
            }

            /* Watch for validity changes and show/hide the element */
            scope.$watch(expression, function(invalid) {
                $animate[invalid ? "removeClass" : "addClass"](element, "ng-hide", {
                    tempClasses: "ng-hide-animate"
                });
            });
        }
    }));
};



//== ui/cmp/inputFileDirective.js =============================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.inputFileDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "E",
        require: "ngModel",

        /**
         * @param {!angular.Scope} scope
         * @param {!angular.JQLite} element
         * @param {!angular.Attributes} attrs
         * @param {!angular.NgModelController} ngModelController
         */
        link: function(scope, element, attrs, ngModelController) {
            var type = attrs["type"];
            if (type !== "file") {
                return;
            }
            element.on("change", function() {
                ngModelController.$setViewValue(element.prop("files"));// FileList
            });
            ngModelController.$validators["required"] = function(modelValue, viewValue) {
                return (modelValue !== null && modelValue.length > 0);
            };
        }
    }));
};



//== ui/cmp/oneDayIncreaserDirective.js =======================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.oneDayIncreaserDirective = function() {

    /**
     * @const {number}
     */
    var OFFSET = (86400000 - 1);// 1 day - 1 ms

    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",
        require: "ngModel",

        /**
         * @param {!angular.Scope} scope
         * @param {!angular.JQLite} element
         * @param {!angular.Attributes} attrs
         * @param {!angular.NgModelController} ngModelController
         */
        link: function(scope, element, attrs, ngModelController) {
            ngModelController.$parsers.push(function(value) {
                if (value) {
                    return new Date(value.valueOf() + OFFSET);
                }
                return value;
            });
        }
    }));
};



//== ui/cmp/sorterPropertyDirective.js ========================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.sorterPropertyDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",
        require: "^uiSorter",
        scope: true,

        /**
         * @param {!angular.Scope} scope
         * @param {!angular.JQLite} element
         * @param {!angular.Attributes} attrs
         * @param {!ui.cmp.SorterController} sorterCtrl
         */
        link: function(scope, element, attrs, sorterCtrl) {
            var property = attrs["uiSorterProperty"];
            if (!property) {
                throw new Error("No sorter property specified");
            }

            /* Publish shorthand properties for accessing one sorter controller property */
            Object.defineProperties(scope, {
                toggle: {
                    value: function() {
                        sorterCtrl.toggle(property);
                    }
                },
                toggleAndApply: {
                    value: function() {
                        sorterCtrl.toggle(property);
                        return sorterCtrl.apply();
                    }
                },
                ascending: {
                    get: function() {
                        var crit = sorterCtrl["criteria"][property];
                        return crit ? crit.ascending : null;
                    }
                },
                descending: {
                    get: function() {
                        var crit = sorterCtrl["criteria"][property];
                        return crit ? crit.descending : null;
                    }
                }
            });
        }
    }));
};



//== ui/cmp/TabsController.js =================================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.Scope} $scope
 * @param {!angular.JQLite} $element
 * @param {!angular.Attributes} $attrs
 * @param {!angular.$timeout} $timeout
 * @param {!angular.$route} $route
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.cmp.TabsController = function($scope, $element, $attrs, $timeout, $route, $location, $log) {

    /** @private */
    this._element = $element;

    /** @private */
    this._scope = $scope;

    /** @private */
    this._route = $route;

    /** @private */
    this._location = $location;

    /** @private */
    this._log = $log;

    /* Compute configuration to enable routing */
    var routeConfing = this._computeRouteConfig($element);

    /** @private */
    this._routeParent = routeConfing && routeConfing.tabsCtrl;

    /** @private */
    this._routeParentNames = routeConfing && routeConfing.names;

    /**
     * @private
     * @type {!Array<ui.cmp.TabsController>}
     */
    this._routeChildren = [];

    /**
     * @private
     * @type {!Object<string,!ui.cmp.TabsPaneController>}
     */
    this._panes = {};

    /**
     * @private
     * @type {?ui.cmp.TabsPaneController}
     */
    this._defaultPane = null;

    /* Tabs and panes state */

    /** @type {!Array<string>} */
    this.paneNames = [];

    /** @type {?ui.cmp.TabsPaneController} */
    this.activePane = null;

    /* Schedule the activation of the default pane */
    $timeout(function() {
        this._handleChangedInternalPath($route.current.pathParams["internalPath"]);
    }.bind(this), 0);

    /* Start listening for internal path changes, only at the root of a routable tabs hierarchy */
    if (this._routeParentNames && !this._routeParent) {
        $scope.$on("uiInternalPathChanged", function(event, internalPath) {
            this._handleChangedInternalPath(internalPath);
        }.bind(this));
    }
};

/**
 * @private
 * @param {!angular.JQLite} $element
 * @return {?{tabsCtrl:?ui.cmp.TabsController, names:!Array<string>}}
 */
ui.cmp.TabsController.prototype._computeRouteConfig = function($element) {

    /* If not routable, there are no parents */
    var routable = ($element.attr("routable") !== undefined);
    if (!routable) {
        return null;
    }

    /* Look for other conflicting routable TABS */
    var siblingTabsCtrls = [];
    this._findSiblingTabs(siblingTabsCtrls, ui.cmp.TabsController._findRootPane($element));
    siblingTabsCtrls.forEach(function(tabsCtrl) {
        if (tabsCtrl._routeParents) {
            throw new Error("Found conflicting routable tabs");
        }
    });

    /* Traverse the DOM by looking for the closest TAB PANE that must be part of a routable tabs */
    for (var current = $element; !!current[0]; current = current.parent()) {
        if (!ui.cmp.TabsPaneController.isAttachedTo(current)) {
            continue;
        }
        var paneName = current.attr("name");
        if (!paneName) {
            throw new Error("Tabs parent pane has no name");
        }
        var tabsCtrl = ( /** @type {?ui.cmp.TabsController} */
        (current.controller("uiTabs")));
        if (!tabsCtrl._routeParentNames) {
            throw new Error("Routable tabs must be at first level or within another set of routable tabs");
        }
        return {
            tabsCtrl: tabsCtrl,
            names: tabsCtrl._routeParentNames.concat(paneName)
        };
    }

    /* No parent TAB PANE found: this is the root of the routable tab hierarchy */
    return {
        tabsCtrl: null,
        names: []
    };
};

/**
 * @private
 * @param {!Array<!ui.cmp.TabsController>} result
 * @param {!angular.JQLite} $element
 */
ui.cmp.TabsController.prototype._findSiblingTabs = function(result, $element) {
    var children = $element.children();
    for (var i = 0; i < children.length; i++) {
        var current = children.eq(i);
        var tabsCtrl = current.controller("uiTabs");
        if (tabsCtrl) {
            if (tabsCtrl !== this && tabsCtrl._element[0] === current[0]) {
                result.push(tabsCtrl);
            }
        } else if (!ui.cmp.TabsPaneController.isAttachedTo(current)) {
            this._findSiblingTabs(result, current); // recurse
        }
    }
};

/**
 * @private
 * @param {!angular.JQLite} $element
 * @return {!angular.JQLite}
 */
ui.cmp.TabsController._findRootPane = function($element) {
    for (var current = $element; !!current.parent()[0]; current = current.parent()) {
        if (ui.cmp.TabsPaneController.isAttachedTo(current)) {
            break;
        }
    }
    return current;
};

/**
 * @package
 * @param {!ui.cmp.TabsPaneController} paneCtrl
 */
ui.cmp.TabsController.prototype.addPane = function(paneCtrl) {
    if (this._panes.hasOwnProperty(paneCtrl)) {
        throw new Error("Duplicate tabs pane name '" + paneCtrl.name + "'")
    }
    if (this._defaultPane && paneCtrl.defaultActive) {
        throw new Error("Multiple default tabs panes");
    }
    this._panes[paneCtrl.name] = paneCtrl;
    if (paneCtrl.defaultActive) {
        this._defaultPane = paneCtrl;
    }
    this.paneNames.push(paneCtrl.name);
};

/**
 * @private
 * @param {?ui.cmp.TabsController} tabsCtrl
 */
ui.cmp.TabsController.prototype._addChildRoutableTabs = function(tabsCtrl) {
    this._routeChildren.push(tabsCtrl);
};

/**
 * @private
 * @param {string} internalPath
 * @param {boolean} pushHistoryState
 */
ui.cmp.TabsController.prototype._updateInternalPath = function(internalPath, pushHistoryState) {
    if (this._routeParent) {
        return this._routeParent._updateInternalPath(internalPath, false); // recurse
    }

    /* Set the path only if changed */
    var oldInternalPath = this._route.current.pathParams["internalPath"];
    if (oldInternalPath !== internalPath) {
        oldInternalPath = oldInternalPath ? "/" + oldInternalPath : "";
        internalPath = internalPath ? "/" + internalPath : "";

        var path = this._location.path();
        if (!oldInternalPath || path.indexOf(oldInternalPath) === path.length - oldInternalPath.length) {
            var basePath = path.substring(0, path.length - oldInternalPath.length);
            this._location.path(basePath + internalPath);
            if (!pushHistoryState) {
                this._location.replace();
            }
            ui.applyScope(this._scope);
        } else {
            throw new Error("Unexpected path");
        }
    }
};

/**
 * @private
 * @param {string} internalPath
 */
ui.cmp.TabsController.prototype._handleChangedInternalPath = function(internalPath) {
    if (internalPath) {
        this._handleChangedRoute(internalPath.split("/"));
    } else {
        this._handleChangedRoute([]);
    }
};

/**
 * @private
 * @param {!Array<string>} names
 */
ui.cmp.TabsController.prototype._handleChangedRoute = function(names) {

    /* React only if the route parent names are the same */
    var routeParentNames = this._routeParentNames;
    if (names.length < routeParentNames.length) {
        return;
    }
    for (var i = 0; i < routeParentNames.length; i++) {
        if (names[i] !== routeParentNames[i]) {
            return; // not interested
        }
    }

    /* Determine the name of the tab to activate (including the possibility of default and no tab) */
    var activatedName, usedDefault;
    if (names.length > routeParentNames.length) {
        activatedName = names[routeParentNames.length];
        usedDefault = false;
    } else if (this._defaultPane) {
        activatedName = this._defaultPane.name;
        usedDefault = true;
    } else {
        activatedName = null;
        usedDefault = false;
    }

    /* Switch the current tabs, then alert children */
    this._activate(activatedName, usedDefault, false);
    this._routeChildren.forEach(function(childCtrl) {
        childCtrl._handleChangedRoute(names); // recurse
    });
};

/**
 * @return {undefined}
 */
ui.cmp.TabsController.prototype.activateDefault = function() {
    if (!this._defaultPane) {
        throw new Error("Tabs have no default pane");
    }
    this.activate(this._defaultPane.name);
};

/**
 * @param {string} name
 * @return {undefined}
 */
ui.cmp.TabsController.prototype.activate = function(name) {
    this._activate(name, true, true);
};

/**
 * @private
 * @param {?string} name
 * @param {boolean} updatePath
 * @param {boolean} pushHistory
 * @return {undefined}
 */
ui.cmp.TabsController.prototype._activate = function(name, updatePath, pushHistory) {
    if (name) {
        var paneCtrl = this._panes[name];
        if (!paneCtrl) {
            throw new Error("Invalid tab pane name '" + name + "'");
        }
        if (this.activePane && this.activePane.name === name) {
            return;
        }
        if (DEBUG) {
            this._log.debug("Activating tab " + name);
        }
        this.activePane = paneCtrl;
    } else {
        this._log.debug("Deactivating tab");
        this.activePane = null;
    }

    /* Update the internal path */
    if (updatePath && this._routeParentNames) {
        this._updateInternalPath(this._routeParentNames.concat(name).join("/"), pushHistory);
    }
};




//== ui/cmp/tabsDirective.js ==================================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.tabsDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "E",
        scope: true,
        controller: ui.cmp.TabsController,
        controllerAs: "tabs"
    }));
};



//== ui/cmp/TabsPaneController.js =============================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.Scope} $scope
 * @param {!angular.JQLite} $element
 * @param {!angular.Attributes} $attrs
 */
ui.cmp.TabsPaneController = function($scope, $element, $attrs) {

    /**
     * @package
     * @type {string}
     */
    this.name = $attrs["name"];

    /**
     * @package
     * @type {boolean}
     */
    this.defaultActive = ($attrs["default"] !== undefined);

    /** @private */
    this._element = $element;

    /* Register with the parent tabs */
    $element.controller("uiTabs").addPane(this);
};

/**
 * @package
 * @param {!angular.JQLite} element
 * @return {boolean}
 */
ui.cmp.TabsPaneController.isAttachedTo = function(element) {
    var ctrl = element.controller("uiTabsPane");
    return (ctrl ? ctrl._element[0] === element[0] : false);
};



//== ui/cmp/tabsPaneDirective.js ==============================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.tabsPaneDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "E",
        require: "^uiTabs",
        scope: true,
        transclude: true,
        controller: ui.cmp.TabsPaneController,
        controllerAs: "tabsPane",
        template: '<ng-transclude ng-if="tabsPane.name === tabs.activePane.name"></ng-transclude>'
    }));
};



//== ui/cmp/tabsTabDirective.js ===============================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.tabsTabDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",
        require: "^uiTabs",
        scope: true,

        /**
         * @param {!angular.Scope} scope
         * @param {!angular.JQLite} element
         * @param {!angular.Attributes} attrs
         * @param {!ui.cmp.TabsController} tabsCtrl
         */
        link: function(scope, element, attrs, tabsCtrl) {
            var name = attrs["uiTabsTab"];
            if (!name) {
                throw new Error("No tabs pane name specified");
            }

            /* Publish shorthand properties pertaining a single tab */
            Object.defineProperties(scope, {
                activate: {
                    value: function() {
                        tabsCtrl.activate(name);
                    }
                },
                active: {
                    get: function() {
                        var activePaneCtrl = tabsCtrl.activePane;
                        return activePaneCtrl && activePaneCtrl.name === name;
                    }
                }
            });
        }
    }));
};



//== ui/cmp/validateEqualDirective.js =========================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.validateEqualDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",
        require: "ngModel",

        /**
         * @param {!angular.Scope} scope
         * @param {!angular.JQLite} element
         * @param {!angular.Attributes} attrs
         * @param {!angular.NgModelController} ngModelController
         */
        link: function(scope, element, attrs, ngModelController) {

            var otherFieldName = attrs["uiValidateEqual"];
            var formCtrl = ngModelController["$$parentForm"];// TODO
            var otherFieldCtrl = formCtrl[otherFieldName];
            otherFieldCtrl.$viewChangeListeners.push(function() {
                ngModelController.$validate();
            });
            ngModelController.$validators["uiEqualValidator"] = function(modelValue, viewValue) {
                if (modelValue === "") {
                    if (ngModelController.$validators["required"]) {
                        return true;// delegated to other validator
                    }
                    if (otherFieldCtrl.$modelValue === undefined) {
                        return true;
                    }
                }
                return (otherFieldCtrl.$modelValue === modelValue);
            };

        }
    }));
};



//== ui/ConfigService.js ======================================================

/**
 * @ngInject
 * @constructor
 * @param {!angular.JQLite} $rootElement
 * @param {!angular.$log} $log
 */
ui.ConfigService = function($rootElement, $log) {

    /** @private */
    this._values = this._readConfig($rootElement);

    if (DEBUG) {
        $log.debug("Configuration " + this._values);
    }
};

/**
 * @private
 * @param {!angular.JQLite} $rootElement
 * @return {!Object<string,*>}
 */
ui.ConfigService.prototype._readConfig = function($rootElement) {

    /* Retrieve the configuration objects */
    var scripts = $rootElement[0].querySelectorAll(".wrConfiguration");
    var objects = Array.prototype.map.call(scripts, function(script) {
        var jsonText = /** @type {string} */
        (angular.element(script).text());
        try {
            return JSON.parse(jsonText);
        } catch (e) {
            throw new Error("Error in configuration script: " + e.message + "\nSript:\n" + jsonText);
        }
    }, this);

    /* Merge configuration objects into a single one */
    objects.unshift({});
    var config = angular.merge.apply(angular, objects);

    return config;
};

/**
 * @template T
 * @param {string} key
 * @param {T=} defaultValue
 * @return {T}
 */
ui.ConfigService.prototype.get = function(key, defaultValue) {
    var value = this._values[key];
    if (value === undefined) {
        if (defaultValue !== undefined) {
            return defaultValue;
        } else {
            throw new Error("Missing configuration value '" + key + "'");
        }
    }
    return value;
};




//== ui/ctrl/AbortedTasks.js ==================================================

ui.ctrl = {};

/**
 * @constructor
 * @ngInject
 * @param {!angular.$log} $log
 */
ui.ctrl.AbortedTasks = function($log) {};

/**
 * @package
 * @const {string}
 */
ui.ctrl.AbortedTasks.VIEW_NAME = "abortedTasks";




//== ui/ctrl/Dialog.js ========================================================

/**
 * @constructor
 * @template T
 * @ngInject
 * @param {!angular.Scope} $scope
 */
ui.ctrl.Dialog = function($scope) {

    /**
     * @param {T} result
     */
    this.close = function(result) {
        $scope["$close"](result);
    };

    /**
     * @return {undefined}
     */
    this.dismiss = function() {
        $scope["$dismiss"]();
    };
};




//== ui/ctrl/ChangePassword.js ================================================

/**
 * @constructor
 * @extends ui.ctrl.Dialog<ui.ctrl.ChangePassword>
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!angular.Scope} $scope
 * @param {!angular.$log} $log
 */
ui.ctrl.ChangePassword = function(uiBackEnd, $scope, $log) {
    ui.ctrl.Dialog.call(this, $scope);

    /**
     * @return {undefined}
     */
    this.performOk = function(result) {
        if (this.dismissed) {
            return;
        }
        uiBackEnd.changeUserPassword(this.userId, this.oldPassword, this.newPassword).then(function() {
            $log.debug("Changed password");
            this.close(this);
        }.bind(this), function(e) {
            $log.debug("Changed password failed");
            this.errorMessage = e["message"];
            ui.applyScope($scope);
        }.bind(this));
    };

    /* Page state variables */

    /** @type {number} */
    this.userId = $scope["userId"];

    /** @type {string} */
    this.oldPassword = "";

    /** @type {string} */
    this.newPassword = "";

    /** @type {string} */
    this.confirmNewPassword = "";

    /** @type {string|undefined} */
    this.errorMessage = undefined;

};

extendConstructor(ui.ctrl.ChangePassword, ui.ctrl.Dialog);




//== ui/ctrl/HistoricProcesses.js =============================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.$log} $log
 */
ui.ctrl.HistoricProcesses = function(uiBackEnd, $scope, $log) {

    /**
     * @see com.webratio.bpm.data.ExecStatus
     * @const
     * @type {!Array<!Object>}
     */
    this.AVAILABLE_STATUSES = [

        {
            "value": "",
            "label": "No Selection"
        },

        {
            "value": "COMPLETED",
            "label": "Completed"
        },

        {
            "value": "CANCELLED",
            "label": "Cancelled"
        },

        {
            "value": "ABORTED",
            "label": "Aborted"
        }

    ];

    /**
     * @return {!Promise}
     */
    this.initializeController = function() {
        return uiBackEnd.listRoles().then(function(data) {

            // compute role names
            var roleNames = {};// only for string!
            data.forEach(function(role) {
                roleNames[role["name"]] = true;
            }, this);
            var availableRoleNamesTemp = Object.keys(roleNames);
            availableRoleNamesTemp.sort(function(x, y) {
                var a = String(x).toUpperCase();
                var b = String(y).toUpperCase();
                if (a > b) {
                    return 1
                }
                if (a < b) {
                    return -1
                }
                return 0;
            });
            this.availableRoleNames = availableRoleNamesTemp;

        }.bind(this)).then(function() {

            // compute process definition names
            return uiBackEnd.listProcessDefinitions().then(function(data) {
                var definitionNames = {};// only for string!
                data.forEach(function(definition) {
                    definitionNames[definition["name"]] = true;
                }, this);
                var availableDefinitionNamesTemp = Object.keys(definitionNames);
                availableDefinitionNamesTemp.sort(function(x, y) {
                    var a = String(x).toUpperCase();
                    var b = String(y).toUpperCase();
                    if (a > b) {
                        return 1
                    }
                    if (a < b) {
                        return -1
                    }
                    return 0;
                });
                this.availableProcessDefinitionNames = availableDefinitionNamesTemp;

                // in the end
                ui.applyScope($scope);
            }.bind(this));
        }.bind(this));
    };

    this.initializeController();

    /* Page state variables */

    /** @type {!Array<string>} */
    this.availableRoleNames = [];

    /** @type {!Array<string>} */
    this.availableProcessDefinitionNames = [];
};

/**
 * @package
 * @const {string}
 */
ui.ctrl.HistoricProcesses.VIEW_NAME = "historicProcesses";




//== ui/ctrl/Home.js ==========================================================

/**
 * @constructor
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!angular.Scope} $rootScope
 */
ui.ctrl.Home = function(uiBackEnd, $rootScope) {

    /**
     * @return {undefined}
     */
    this.refresh = function() {
        this.initializeController();
    }

    /**
     * @return {!Promise}
     */
    this.initializeController = function() {
        return uiBackEnd.listProcesses(new rest.data.Query(new rest.data.filter.Term(rest.data.filter.Operator.EQUAL,
                rest.data.Ref.parse("status"), "ACTIVE"), [], new rest.data.Paging(1, 0))).then(function(processes) {
                    // retrieve ACTIVE processes count
                    var activeProcessesCountTemp = rest.data.ResultSet.extractMetadata(processes).getTotalCount();
                    this.activeProcessesCount = (activeProcessesCountTemp ? activeProcessesCountTemp : 0);
                }.bind(this)).then(function() {
                    uiBackEnd.listProcesses(new rest.data.Query(new rest.data.filter.Term(rest.data.filter.Operator.EQUAL,
                            rest.data.Ref.parse("status"), "SUSPENDED"), [], new rest.data.Paging(1, 0))).then(function(processes) {
                                // retrieve SUSPEND processes
                                // count
                                var suspendedProcessesCountTemp = rest.data.ResultSet.extractMetadata(processes).getTotalCount();
                                this.suspendedProcessesCount = (suspendedProcessesCountTemp ? suspendedProcessesCountTemp : 0);
                                // in the end
                                ui.applyScope($rootScope);
                            }.bind(this)

                    );
                }.bind(this));
    };

    this.initializeController();

    /* Page state variables */

    /** @type {number} */
    this.activeProcessesCount = 0;

    /** @type {number} */
    this.suspendedProcessesCount = 0;

};

/**
 * @package
 * @const {string}
 */
ui.ctrl.Home.VIEW_NAME = "home";




//== ui/ctrl/NewDeploy.js =====================================================

/**
 * @constructor
 * @extends ui.ctrl.Dialog<ui.ctrl.NewDeploy>
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!angular.Scope} $scope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.NewDeploy = function(uiBackEnd, $scope, $location, $log) {
    ui.ctrl.Dialog.call(this, $scope);

    /**
     * @return {undefined}
     */
    this.performOk = function(result) {
        if (this.dismissed) {
            return;
        }
        if (this.fileList === null || this.fileList.length !== 1) {
            throw new Error("Invalid file list length");
        }
        var file = this.fileList[0];
        uiBackEnd.uploadProcessArchiveFile(file).then(function() {
            $log.debug("Deployed process archive");
            this.close(this);
            $location.path("processArchives");
        }.bind(this), function(e) {
            $log.debug("Deployed process archive failed");
            this.errorMessage = e["message"];
            ui.applyScope($scope);
        }.bind(this));
    };

    /* Page state variables */

    /** @type {?FileList} */
    this.fileList = null;

    /** @type {string|undefined} */
    this.errorMessage = undefined;

};

extendConstructor(ui.ctrl.NewDeploy, ui.ctrl.Dialog);




//== ui/ctrl/ProcessArchives.js ===============================================

/**
 * @constructor
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!angular.Scope} $scope
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.$log} $log
 */
ui.ctrl.ProcessArchives = function(uiBackEnd, uiAlerter, uiDialog, $scope, $log) {

    /**
     * @param {!number} archiveId
     * @return {!Promise}
     */
    this.deleteArchive = function(archiveId) {
        return uiDialog.showDangerConfirm("Are you sure?", [ "Delete", "Cancel" ]).then(function(index) {
            if (index !== 0) {
                return;
            }
            return uiBackEnd.deleteProcessArchive(archiveId).then(function() {
                $log.debug("Deleted process archive");
                ui.applyScope($scope);
                $scope.$broadcast("uiDataFamilyUpdated", "processArchives");
            }.bind(this), function(e) {
                $log.debug("Deleted process archive failed");
                uiAlerter.showError(e.message);
            }.bind(this));
        }.bind(this))
    };

};

/**
 * @package
 * @const {string}
 */
ui.ctrl.ProcessArchives.VIEW_NAME = "processArchives";




//== ui/ctrl/ProcessDefinition.js =============================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.$routeParams} $routeParams
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.StorageService} uiStorage
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.ProcessDefinition = function($routeParams, uiBackEnd, uiStorage, uiAlerter, uiDialog, $rootScope, $location, $log) {

    /**
     * @const {string}
     */
    this.processDefinitionId = String($routeParams["processDefinitionId"]);

    /**
     * @param {!Object} processDefinition
     * @return {undefined}
     */
    this.prefillForm = function(processDefinition) {
        this.processDefinition = processDefinition;
    };

    /**
     * @return {!Promise}
     */
    this.setParameters = function() {

        /* collect all available start events and messages */
        var startEvents = [];
        this.processDefinition["userStartEvents"].forEach(function(item) {
            item.type = "StartEvent";
            startEvents.push(item);
        });
        this.processDefinition["catchingMessageEvents"].forEach(function(item) {
            if (item.type === "StartMessage") {
                startEvents.push(item);
            }
        });
        this.startEvents = startEvents;

        return uiDialog.showDialog({
            templateUrl: "dialogs/setStartingProcessParameters.html",
            controller: ui.ctrl.SetStartingProcessParameters,
            data: {

                "processDefinition": this.processDefinition,

                "startEvents": this.startEvents

            }
        });
    }

    /* Page state variables */

    /** @type {?Object} */
    this.processDefinition = null;

    /** @type {?Object} */
    this.startEvents = null;
};

/**
 * @package
 * @const {string}
 */
ui.ctrl.ProcessDefinition.VIEW_NAME = "processDefinition";

/**
 * @package
 * @const {string}
 */
ui.ctrl.ProcessDefinition.VIEW_PARAM = "processDefinitionId";




//== ui/ctrl/ReassignCandidateUsersAndRoles.js ================================

/**
 * @constructor
 * @extends ui.ctrl.Dialog<ui.ctrl.ReassignCandidateUsersAndRoles>
 * @ngInject
 * @param {!angular.Scope} $scope
 */
ui.ctrl.ReassignCandidateUsersAndRoles = function($scope) {
    ui.ctrl.Dialog.call(this, $scope);

    /**
     * @param {!Object} user
     * @return {undefined}
     */
    this.assignUser = function(user) {
        this.user = user;
        this.close(this)
    };

    /**
     * @param {!string} role
     * @return {undefined}
     */
    this.assignRole = function(role) {
        this.role = role;
        this.close(this)
    };

    /* Page state variables */
    var inputDialog = $scope["inputDialog"];

    /** @type {string} */
    this.taskId = inputDialog["taskId"];

    /** @type {?Object|undefined} */
    this.user = undefined;

    /** @type {?string} */
    this.role = "";

};

extendConstructor(ui.ctrl.ReassignCandidateUsersAndRoles, ui.ctrl.Dialog);




//== ui/ctrl/Registrations.js =================================================

/**
 * @constructor
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$log} $log
 */
ui.ctrl.Registrations = function(uiBackEnd, uiAlerter, uiDialog, $rootScope, $log) {

    /** @private */
    this._uiBackEnd = uiBackEnd;

    /**
     * @return {!Promise}
     */
    this.initializeController = function() {
        return uiBackEnd.listRoles(null).then(function(data) {
            var roleNames = {};// only for string!
            data.forEach(function(role) {
                roleNames[role["name"]] = true;
            }, this);
            var availableRoleNamesTemp = Object.keys(roleNames);
            availableRoleNamesTemp.sort(function(x, y) {
                var a = String(x).toUpperCase();
                var b = String(y).toUpperCase();
                if (a > b) {
                    return 1
                }
                if (a < b) {
                    return -1
                }
                return 0;
            });
            this.availableRoleNames = availableRoleNamesTemp;

            // in the end
            ui.applyScope($rootScope);
        }.bind(this));
    };

    /**
     * @param {number} userId
     * @return {undefined}
     */
    this.setRoles = function(userId) {
        uiDialog.showDialog({
            templateUrl: "dialogs/roles.html",
            controller: ui.ctrl.Roles,
            data: {
                "availableRoleNames": this.availableRoleNames
            }
        }).then(function(result) {
            if (result.dismissed) {
                return;
            }
            var ctrl = result.value;
            if (!ctrl) {
                return;
            }
            if (!ctrl.roles || ctrl.roles.length <= 0) {
                $log.debug("No selected roles");
                return;
            }

            var data = {};
            data["roles"] = ctrl.roles;
            return this._uiBackEnd.updateUser(userId, data).then(function() {
                $log.debug("Changed roles");
                ui.applyScope($rootScope);
                $rootScope.$broadcast("uiDataFamilyUpdated", "users");
            }.bind(this), function(e) {
                $log.debug("Changed roles failed");
                uiAlerter.showError(e.message);
            }.bind(this));
        }.bind(this));
    };

    this.initializeController();

    /* Page state variables */

    /** @type {!Array} */
    this.availableRoleNames = [];

};

/**
 * @package
 * @const {string}
 */
ui.ctrl.Registrations.VIEW_NAME = "registrations";




//== ui/ctrl/Roles.js =========================================================

/**
 * @constructor
 * @extends ui.ctrl.Dialog<ui.ctrl.Roles>
 * @ngInject
 * @param {!angular.Scope} $scope
 */
ui.ctrl.Roles = function($scope) {
    ui.ctrl.Dialog.call(this, $scope);

    /* Page state variables */

    /** @type {!Array} */
    this.roles = [];

};

extendConstructor(ui.ctrl.Roles, ui.ctrl.Dialog);




//== ui/ctrl/RunningProcesses.js ==============================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.$routeParams} $routeParams
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!angular.Scope} $scope
 * @param {!angular.$log} $log
 */
ui.ctrl.RunningProcesses = function($routeParams, uiBackEnd, $scope, $log) {

    /**
     * @see com.webratio.bpm.data.ExecStatus
     * @const
     * @type {!Array<!Object>}
     */
    this.AVAILABLE_STATUSES = [

        {
            "value": "",
            "label": "No Selection"
        },

        {
            "value": "ABORTED",
            "label": "Aborted"
        },

        {
            "value": "ACTIVE",
            "label": "Active"
        },

        {
            "value": "CANCELLED",
            "label": "Cancelled"
        },

        {
            "value": "COMPLETED",
            "label": "Completed"
        },

        {
            "value": "READY",
            "label": "Ready"
        },

        {
            "value": "SUSPENDED",
            "label": "Suspended"
        }

    ];

    /**
     * @const {string}
     */
    this.inputStatus = $routeParams["inputStatus"];

    // TODO console.log("inputStatus=" + this.inputStatus);// TODO

    /**
     * @return {!Promise}
     */
    this.initializeController = function() {
        return uiBackEnd.listRoles(null).then(function(data) {

            // compute role names
            var roleNames = {};// only for string!
            data.forEach(function(role) {
                roleNames[role["name"]] = true;
            }, this);
            var availableRoleNamesTemp = Object.keys(roleNames);
            availableRoleNamesTemp.sort(function(x, y) {
                var a = String(x).toUpperCase();
                var b = String(y).toUpperCase();
                if (a > b) {
                    return 1
                }
                if (a < b) {
                    return -1
                }
                return 0;
            });
            this.availableRoleNames = availableRoleNamesTemp;

        }.bind(this)).then(function() {

            // compute process definition names
            return uiBackEnd.listProcessDefinitions(null).then(function(data) {
                var definitionNames = {};// only
                // for
                // string!
                data.forEach(function(definition) {
                    definitionNames[definition["name"]] = true;
                }, this);
                var availableDefinitionNamesTemp = Object.keys(definitionNames);
                availableDefinitionNamesTemp.sort(function(x, y) {
                    var a = String(x).toUpperCase();
                    var b = String(y).toUpperCase();
                    if (a > b) {
                        return 1
                    }
                    if (a < b) {
                        return -1
                    }
                    return 0;
                });
                this.availableProcessDefinitionNames = availableDefinitionNamesTemp;

                // in the end
                ui.applyScope($scope);
            }.bind(this));
        }.bind(this));
    };

    this.initializeController();

    /* Page state variables */

    /** @type {!Array<string>} */
    this.availableRoleNames = [];

    /** @type {!Array<string>} */
    this.availableProcessDefinitionNames = [];

};

/**
 * @package
 * @const {string}
 */
ui.ctrl.RunningProcesses.VIEW_NAME = "runningProcesses";




//== ui/ctrl/SetRunningProcessParameters.js ===================================

/**
 * @constructor
 * @extends ui.ctrl.Dialog<ui.ctrl.SetRunningProcessParameters>
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $scope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.SetRunningProcessParameters = function(uiBackEnd, uiAlerter, uiDialog, $scope, $location, $log) {
    ui.ctrl.Dialog.call(this, $scope);

    /**
     * @return {undefined}
     */
    this.performOk = function(result) {
        if (this.dismissed) {
            return;
        }
        if (!this.messageDefinitionId) {
            throw new Error("Missing message definition id");
        }
        var parameterValues = [];
        this.parameters.forEach(function(param) {
            if (!param.value) {
                return;// continue;
            }
            var value = param.value;
            if ("BOOLEAN" === param["type"]) {
                value = ("True" === param.value);
            }
            parameterValues.push({
                "name": param.name,
                "value": value
            });
        }, this);
        var handleCompletedProcessFn = function() {
            uiDialog.showInfoConfirm("Process Completed", [ "OK" ]).then(function(index) {
                if (index !== 0) {
                    return;
                }
                this.close(this);
                $location.path("runningProcesses");
            }.bind(this))
        }.bind(this);
        uiBackEnd.sendMessage(this.processId, this.messageDefinitionId, parameterValues).then(function(result) {
            $log.debug("Sent message");
            uiBackEnd.retrieveProcess(this.processId).then(function(result) {
                var status = result["status"]
                if ("COMPLETED" === status) {
                    // completed
                    handleCompletedProcessFn();
                } else {
                    this.close(this);
                    $location.path("processDetails/" + encodeURIComponent(String(this.processId)));
                }
            }.bind(this), function(e) {
                if (("Process " + this.processId + " not found") === e["message"]) {
                    // completed and archived
                    handleCompletedProcessFn();
                } else {
                    this.close(this);
                    uiAlerter.showError(e.message);// unexpected error
                }
            }.bind(this));
        }.bind(this), function(e) {
            $log.debug("Sent message failed");
            this.errorMessage = e["message"];
            ui.applyScope($scope);
        }.bind(this));
    };

    /**
     * @param {Object} param
     * @return {string}
     */
    this.computeInputType = function(param) {
        var type = param["type"];
        if ("PASSWORD" === type) {
            return "password";
        }
        if ("URL" === type) {
            return "url";
        }
        if ("DATE" === type) {
            return "date";
        }
        if ("TIME" === type) {
            return "time";
        }
        if ("TIMESTAMP" === type) {
            return "datetime-local";
        }
        return "text";
    };

    /* Page state variables */

    /** @type {number} */
    this.processId = $scope["processId"];

    /** @type {Array<Object>} */
    this.availableMessages = $scope["processDefinition"]["catchingMessageEvents"];

    /** @type {?string|undefined} */
    this.messageDefinitionId = undefined;

    /** @type {string|undefined} */
    this.errorMessage = undefined;

    /** @type {Array<Object>} */
    this.parameters = [];
    $scope["processDefinition"]["parameters"].forEach(function(param) {
        if ("ENUM" === param["type"] || "CLASS" === param["type"]) {
            return;// continue
        }
        this.parameters.push({

            "name": param["name"],

            "type": param["type"],

            "value": undefined,

        });

    }, this);

};

extendConstructor(ui.ctrl.SetRunningProcessParameters, ui.ctrl.Dialog);




//== ui/ctrl/SetStartingProcessParameters.js ==================================

/**
 * @constructor
 * @extends ui.ctrl.Dialog<ui.ctrl.SetStartingProcessParameters>
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $scope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.SetStartingProcessParameters = function(uiBackEnd, uiAlerter, uiDialog, $scope, $location, $log) {
    ui.ctrl.Dialog.call(this, $scope);

    /**
     * @return {undefined}
     */
    this.performOk = function(result) {
        if (this.dismissed) {
            return;
        }
        if (!this.startEventId) {
            throw new Error("Missing start event name");
        }
        var parameterValues = [];
        this.parameters.forEach(function(param) {
            if (!param.value) {
                return;// continue;
            }
            var value = param.value;
            if ("BOOLEAN" === param["type"]) {
                value = ("True" === param.value);
            }
            parameterValues.push({
                "name": param.name,
                "value": value
            });
        }, this);
        var handleCompletedProcessFn = function() {
            uiDialog.showInfoConfirm("Process Completed", [ "OK" ]).then(function(index) {
                if (index !== 0) {
                    return;
                }
                this.close(this);
                $location.path("runningProcesses");
            }.bind(this))
        }.bind(this);

        var startEventId = this.startEventId.split("[")[0];
        if (this.startEventId.indexOf("StartMessage") > -1) {
            uiBackEnd.sendMessageNoProcess(startEventId, parameterValues).then(function(result) {
                $log.debug("Start process");
                this.close(this);
                $location.path("runningProcesses");
            }.bind(this), function(e) {
                $log.debug("Start process failed");
                this.errorMessage = e["message"];
                ui.applyScope($scope);
            }.bind(this));
        } else {
            uiBackEnd.startProcess(this.processName, startEventId, parameterValues).then(function(result) {
                $log.debug("Start process");
                this.close(this);
                $location.path("runningProcesses");
            }.bind(this), function(e) {
                $log.debug("Start process failed");
                this.errorMessage = e["message"];
                ui.applyScope($scope);
            }.bind(this));
        }
    };

    /**
     * @param {Object} param
     * @return {string}
     */
    this.computeInputType = function(param) {
        var type = param["type"];
        if ("PASSWORD" === type) {
            return "password";
        }
        if ("URL" === type) {
            return "url";
        }
        if ("DATE" === type) {
            return "date";
        }
        if ("TIME" === type) {
            return "time";
        }
        if ("TIMESTAMP" === type) {
            return "datetime-local";
        }
        return "text";
    };

    /* Page state variables */

    /** @type {string} */
    this.processId = $scope["modelId"];

    /** @type {string} */
    this.processName = $scope["processDefinition"]["name"];

    /** @type {Array<Object>} */
    this.availableStartEvents = $scope["startEvents"];

    /** @type {?string|undefined} */
    this.startEventId = undefined;

    /** @type {string|undefined} */
    this.errorMessage = undefined;

    /** @type {Array<Object>} */
    this.parameters = [];
    $scope["processDefinition"]["parameters"].forEach(function(param) {
        if ("ENUM" === param["type"] || "CLASS" === param["type"]) {
            return;// continue
        }
        this.parameters.push({

            "name": param["name"],

            "type": param["type"],

            "value": undefined,

        });

    }, this);

};

extendConstructor(ui.ctrl.SetStartingProcessParameters, ui.ctrl.Dialog);




//== ui/ctrl/StartProcess.js ==================================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.$log} $log
 */
ui.ctrl.StartProcess = function($log) {
    // TODO
};

/**
 * @package
 * @const {string}
 */
ui.ctrl.StartProcess.VIEW_NAME = "startProcess";




//== ui/ctrl/Users.js =========================================================

/**
 * @constructor
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $scope
 */
ui.ctrl.Users = function(uiBackEnd, uiDialog, $scope) {

    /**
     * @return {!Promise}
     */
    this.initializeController = function() {
        return uiBackEnd.listRoles(null).then(function(data) {
            var roleNames = {};// only for string!
            data.forEach(function(role) {
                roleNames[role["name"]] = true;
            }, this);
            var availableRoleNamesTemp = Object.keys(roleNames);
            availableRoleNamesTemp.sort(function(x, y) {
                var a = String(x).toUpperCase();
                var b = String(y).toUpperCase();
                if (a > b) {
                    return 1
                }
                if (a < b) {
                    return -1
                }
                return 0;
            });
            this.availableRoleNames = availableRoleNamesTemp;

            // in the end
            ui.applyScope($scope);
        }.bind(this));
    };

    this.initializeController();

    /* Page state variables */

    /** @type {!Array<string>} */
    this.availableRoleNames = [];

};

/**
 * @package
 * @const {string}
 */
ui.ctrl.Users.VIEW_NAME = "users";




//== ui/dir/showActiveDirective.js ============================================

ui.dir = {};

/**
 * @ngInject
 * @param {!angular.$location} $location
 * @return {!angular.Directive}
 */
ui.dir.showActiveDirective = function($location) {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",

        /**
         * @param {!angular.Scope} scope
         * @param {!angular.JQLite} element
         * @param {!angular.Attributes} attrs
         */
        link: function(scope, element, attrs) {
            var className = attrs["uiShowActive"];

            /* Collect all HREF on descendants and self */
            var hrefPaths = {};
            Array.prototype.forEach.call(element.find("a")["andSelf"](), function(el) {
                var href = angular.element(el).attr("href");
                var m;
                if (m = /^#(.+)$/.exec(href)) {
                    hrefPaths[m[1]] = true;
                }
            });

            /* When the route changes, toggle the active classes */
            function updateActive() {
                if (hrefPaths[$location.path()] === true) {
                    element.addClass(className);
                } else {
                    element.removeClass(className);
                }
            }
            scope.$on("$routeChangeSuccess", updateActive);

            /* Do a first update */
            updateActive();
        }
    }));
};



//== ui/dir/_dir.js ===========================================================

/**
 * @name ui.dir
 * @namespace
 */

/**
 * rest.data.Type.TIMESTAMP e.g. 1977-01-15T10:09:08.007+0100
 */
ui.dir.TIMESTAMP_CONVERTER = {
    fromRaw: rest.data.toSingle.bind(rest.data, function(value) {
        if (typeof value !== "string") {
            throw new Error("Expected a string as raw value but got " + value);
        }
        return rest.data.Timestamp.fromString(value);
    }),
    toRaw: rest.data.toSingle.bind(rest.data, function(value) {
        if (!(value instanceof Date)) {
            throw new Error("Expected a Date as value but got " + value);
        }
        return rest.data.Timestamp.asString(value);
    })
};




//== ui/localizeFilter.js =====================================================

/**
 * @ngInject
 * @return {function(string):string} A filter function, accepting a key and returning a localized message.
 */
ui.localizeFilter = function() {
    function filter(key) {
        // TODO
        return key;
    }

    return filter;
};



//== ui/StorageService.js =====================================================

/**
 * @constructor
 */
ui.StorageService = function() {

    /** @private */
    this._local = GLOBAL.localStorage;

    /** @private */
    this._session = GLOBAL.sessionStorage;
};

/**
 * @param {string} key
 * @return {?string}
 */
ui.StorageService.prototype.getLocal = function(key) {
    return this._local.getItem(this._mangleKey(key));
};

/**
 * @param {string} key
 * @param {string} value
 */
ui.StorageService.prototype.setLocal = function(key, value) {
    this._local.setItem(this._mangleKey(key), value);
};

/**
 * @param {string} key
 */
ui.StorageService.prototype.removeLocal = function(key) {
    this._local.removeItem(this._mangleKey(key));
};

/**
 * @param {string} key
 * @return {?string}
 */
ui.StorageService.prototype.getSession = function(key) {
    return this._session.getItem(this._mangleKey(key));
};

/**
 * @param {string} key
 * @param {string} value
 */
ui.StorageService.prototype.setSession = function(key, value) {
    this._session.setItem(this._mangleKey(key), value);
};

/**
 * @param {string} key
 */
ui.StorageService.prototype.removeSession = function(key) {
    this._session.removeItem(this._mangleKey(key));
};

/**
 * @private
 * @param {string} key
 * @return {string}
 */
ui.StorageService.prototype._mangleKey = function(key) {
    return "wr." + key;
};




//== ui/urlEscapeFilter.js ====================================================

/**
 * @ngInject
 * @return {function(string):string}
 */
ui.urlEscapeFilter = function() {
    function filter(key) {
        return encodeURIComponent(key)
    }

    return filter;
};



//== ui/_ui.js ================================================================

/**
 * @name ui
 * @namespace
 */

/**
 * @internal
 * @param {!angular.Scope} scope
 * @param {function(!angular.Scope)=} callback
 */
ui.applyScope = function(scope, callback) {
    if (!scope.$$phase) {
        scope.$applyAsync(callback);
    } else if (callback) {
        callback(scope);
    }
};

/**
 * @internal
 * @param {*} value
 * @return {boolean}
 */
ui.isPromise = function(value) {
    return (!!value && (typeof value === "object") && ("then" in value));
};

/*
 * Callback interception
 */

/**
 * @private
 * @type {!Array<function(?)>}
 */
ui._interceptedCallbacks = [];

/**
 * @private
 */
ui._automaticCallbacksEnabled = true;

/**
 * @internal
 * @template T
 * @param {T} callback
 * @return {T}
 */
ui.interceptAutomaticCallback = function(callback) {
    if (typeof callback !== "function") {
        return callback;
    }
    return function callbackWrapper() {
        if (ui._automaticCallbacksEnabled) {
            ui._invokeFunctionNoResult(function() {
                callback.apply(this, arguments);
            }.bind(this));
        } else {
            var bindArgs = [ this ].concat(Array.prototype.slice.call(arguments));
            var boundCallback = Function.prototype.bind.apply(callback, bindArgs);
            ui._interceptedCallbacks.push(boundCallback);
        }
    };
};

/**
 * @return {undefined}
 */
ui.suspendAutomaticEvents = function() {
    ui._automaticCallbacksEnabled = false;
};

/**
 * @return {undefined}
 */
ui.resumeAutomaticEvents = function() {
    if (ui._automaticCallbacksEnabled) {
        return;
    }
    ui._automaticCallbacksEnabled = true;
    var boundCallbacks = ui._interceptedCallbacks;
    ui._interceptedCallbacks = [];
    boundCallbacks.forEach(ui._invokeFunctionNoResult);
};

/**
 * @private
 * @param {function()} fn
 */
ui._invokeFunctionNoResult = function(fn) {
    try {
        var retVal = fn();
        if (retVal !== undefined) {
            console.error("Return value of callback may be lost", retVal);
        }
    } catch (e) {
        console.error("Thrown error of callback may be lost", e);
    }
};




//== ui/ActivityService.js ====================================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.Scope} $rootScope
 */
ui.ActivityService = function($rootScope) {

    /** @private */
    this._$rootScope = $rootScope;

    /** @private */
    this._activityCount = 0;
}

/**
 * @return {boolean}
 */
ui.ActivityService.prototype.isActivityRunning = function() {
    return this._activityCount > 0;
};

/**
 * @return {undefined}
 */
ui.ActivityService.prototype.startActivity = function() {
    this._activityCount++;
    if (this._activityCount === 1) {
        this._$rootScope.$broadcast("uiActivityStarted");
    }
};

/**
 * @return {undefined}
 */
ui.ActivityService.prototype.stopActivity = function() {
    this._activityCount--;
    if (this._activityCount === 0) {
        this._$rootScope.$broadcast("uiActivityStopped");
    }
};




//== ui/AlerterService.js =====================================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$log} $log
 * @param {!angular.$timeout} $timeout
 */
ui.AlerterService = function($rootScope, $log, $timeout) {

    /** @private */
    this._$rootScope = $rootScope;
    this._$rootScope["alerts"] = [];

    /** @private */
    this._$log = $log;

    /** @private */
    this._$timeout = $timeout;

}

/**
 * @const
 */
ui.AlerterService.MIN_TIMEOUT = 1000;

/**
 * @const
 */
ui.AlerterService.TIMEOUT_CHAR = 60;// 1 sec.

/**
 * @enum {string}
 */
ui.AlerterService.type = {
    SUCCESS: "alert-success",
    INFO: "alert-info",
    WARNING: "alert-warning",
    ERROR: "alert-danger"
}

/**
 * @return {undefined}
 */
ui.AlerterService.prototype.clearAll = function() {
    this._$rootScope["alerts"] = [];
}

/**
 * @param {string} message
 */
ui.AlerterService.prototype.showSuccess = function(message) {
    this.clearAll();
    this.addAlert(message, ui.AlerterService.type.SUCCESS, true,
            ui.AlerterService.MIN_TIMEOUT + message.length * ui.AlerterService.TIMEOUT_CHAR);
}

/**
 * @param {string} message
 */
ui.AlerterService.prototype.addSuccess = function(message) {
    this.addAlert(message, ui.AlerterService.type.SUCCESS, true,
            ui.AlerterService.MIN_TIMEOUT + message.length * ui.AlerterService.TIMEOUT_CHAR);
}

/**
 * @param {string} message
 */
ui.AlerterService.prototype.showInfo = function(message) {
    this.clearAll();
    this.addAlert(message, ui.AlerterService.type.INFO, true,
            ui.AlerterService.MIN_TIMEOUT + message.length * ui.AlerterService.TIMEOUT_CHAR);
}

/**
 * @param {string} message
 */
ui.AlerterService.prototype.addInfo = function(message) {
    this.addAlert(message, ui.AlerterService.type.INFO, true,
            ui.AlerterService.MIN_TIMEOUT + message.length * ui.AlerterService.TIMEOUT_CHAR);
}

/**
 * @param {string} message
 */
ui.AlerterService.prototype.showWarning = function(message) {
    this.clearAll();
    this.addAlert(message, ui.AlerterService.type.WARNING, true, 0);
}

/**
 * @param {string} message
 */
ui.AlerterService.prototype.addWarning = function(message) {
    this.addAlert(message, ui.AlerterService.type.WARNING, true, 0);
}

/**
 * @param {string} message
 */
ui.AlerterService.prototype.showError = function(message) {
    this.clearAll();
    this.addAlert(message, ui.AlerterService.type.ERROR, true, 0);
}

/**
 * @param {string} message
 */
ui.AlerterService.prototype.addError = function(message) {
    this.addAlert(message, ui.AlerterService.type.ERROR, true, 0);
}

/**
 * @param {string} message
 * @param {!ui.AlerterService.type} type
 * @param {!boolean} closable
 * @param {!number} closeTimeout
 */
ui.AlerterService.prototype.addAlert = function(message, type, closable, closeTimeout) {
    var log = this._$log;
    if (DEBUG) {
        log.info("Add alert '" + message + "' type='" + type + "'");
    }

    var scope = this._$rootScope;
    var alerts = scope["alerts"];
    var alert = {
        "message": message,
        "type": type,
        "closable": closable,
        "close": function() {
            var index = alerts.indexOf(alert);
            if (index < 0) {
                // already removed by timeout
                return false;
            }
            alerts.splice(index, 1);
            if (DEBUG) {
                log.info("Remove alert '" + message + "' #" + index + " type='" + type + "'");
            }
            ui.applyScope(scope);
            return true;
        },
    };
    alerts.push(alert);
    ui.applyScope(scope);

    if (closeTimeout > 0) {
        var timer = this._$timeout(function() {

            if (!alert.close()) {
                // already removed by 'X' button
                return;
            }

        }, closeTimeout);
    }
};




//== ui/AuthService.js ========================================================

/**
 * @constructor
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.StorageService} uiStorage
 */
ui.AuthService = function(uiBackEnd, uiStorage) {

    /** @private */
    this._uiBackEnd = uiBackEnd;

    /** @private */
    this._uiStorage = uiStorage;

    /**
     * @private
     */
    this._user = /** @type {?Object} */
    (JSON.parse(uiStorage.getLocal("loggedUser") || "null"));

    uiBackEnd.initAuthService(this);
};

/**
 * @return {boolean}
 */
ui.AuthService.prototype.isLoggedIn = function() {
    return !!this._user;
};

/**
 * @private
 * @return {!Object}
 */
ui.AuthService.prototype._retrieveUser = function() {
    if (!this._user) {
        throw new Error("Not logged in");
    }
    return this._user;
};

/**
 * @return {string}
 */
ui.AuthService.prototype.retrieveToken = function() {
    return this._retrieveUser().token;
};

/**
 * @return {number}
 */
ui.AuthService.prototype.retrieveUserOid = function() {
    return this._retrieveUser().oid;
};

/**
 * @return {string}
 */
ui.AuthService.prototype.retrieveCurrentUsername = function() {
    if (!this.isLoggedIn()) {
        return "";
    }
    return this._retrieveUser().username;
};

/**
 * @param {string} username
 * @param {string} password
 * @return {!Promise}
 */
ui.AuthService.prototype.login = function(username, password) {
    return this._uiBackEnd.login(username, password).then(function(response) {
        this._user = response.user;
        this._uiStorage.setLocal("loggedUser", JSON.stringify(response.user));
    }.bind(this));
};

/**
 * @return {!Promise}
 */
ui.AuthService.prototype.logout = function() {
    this._user = null;
    this._uiStorage.removeLocal("loggedUser");
    return Promise.resolve();
};




//== ui/cmp/DataViewController.js =============================================

/**
 * @constructor
 * @ngInject
 * @param {ui.cmp.DataViewController.Config} config
 * @param {!angular.Scope} $scope
 * @param {!angular.JQLite} $element
 * @param {!angular.Attributes} $attrs
 * @param {!angular.$parse} $parse
 * @param {!angular.$timeout} $timeout
 * @param {!ui.ActivityService} uiActivity
 */
ui.cmp.DataViewController = function(config, $scope, $element, $attrs, $parse, $timeout, uiActivity) {
    var baseAttrName = config.baseAttrName || config.directiveName;
    var instanceConfig = this._parseInstanceConfig(baseAttrName, $attrs);

    /** @private */
    this._element = $element;

    /** @private */
    this._inputExpr = this._createInputExpression(instanceConfig.expression, $parse);

    /** @private */
    this._fetchData = config.fetchData;

    /** @private */
    this._filterExpr = this._createOptionalExpression(baseAttrName, "Filter", $attrs, $parse);

    /** @private */
    this._refreshedFn = this._createOptionalExpression(baseAttrName, "Refreshed", $attrs, $parse);

    /** @private */
    var refreshInterval = Number($attrs[baseAttrName + "Interval"] || "0");

    /** @private */
    this._dataFamilies = config.dataFamilies;

    /** @private */
    this._references = config.references || {};

    /** @private */
    this._conversions = this._createConversions(config.converters);

    /** @private */
    this._trackingProperty = config.trackingProperty || null;

    /** @private */
    this._scope = $scope;

    /** @private */
    this._uiActivity = uiActivity;

    /* Query pieces */

    /**
     * @private
     * @type {?rest.data.filter.Expression}
     */
    this._queryFilter = null;

    /**
     * @private
     * @type {!Array<!rest.data.SortCriterion>}
     */
    this._querySorting = [];

    /**
     * @private
     * @type {?rest.data.Paging}
     */
    this._queryPaging = null;

    /* State */

    /**
     * @private
     * @type {boolean}
     */
    this.ready = false;

    /**
     * @private
     * @type {boolean}
     */
    this.loading = true;

    /**
     * @private
     * @type {?Array|?Object}
     */
    this.data = null;

    /**
     * @private
     * @type {?string}
     */
    this.error = null;

    /* Publish the controller */
    $scope[instanceConfig.variable || config.variable || "view"] = this;

    /* Watch changes in the input expression */
    if (instanceConfig.expression) {
        this._scope.$watch(instanceConfig.expression, this.refresh.bind(this));
    }

    /* Listen for data family updates */
    if (this._dataFamilies) {
        this._scope.$on("uiDataFamilyUpdated", function(event, family) {
            // refresh when the listened data are changed
            if (this._dataFamilies.indexOf(family) >= 0) {
                this.refresh();
            }
        }.bind(this));
    }

    /* Create refresh promise */
    var schedulePromise = null;
    var scheduleRefresh = ui.interceptAutomaticCallback(function() {
        if (refreshInterval > 0) {
            schedulePromise = $timeout(scheduleRefresh, refreshInterval);
            this.refresh(true);
        }
    }.bind(this));

    /* Schedule a first time */
    $timeout(function() {
        this.refresh();
        scheduleRefresh();
    }.bind(this), 0);

    /* Stop scheduling at dispose */
    $scope.$on("$destroy", function() {
        if (schedulePromise) {
            $timeout.cancel(schedulePromise);
        }
    });
};

/**
 * @typedef {{directiveName:string, variable:string, baseAttrName:(string|undefined),
 *          fetchData:function(*,!rest.data.Query):(!Promise<!Array|!Object>|!Array|!Object), dataFamilies:(Array<string>|undefined),
 *          references:(!Object<string,!rest.data.Ref>|undefined),
 *          converters:(!Object<string,!ui.cmp.DataViewController.Converter>|undefined), trackingProperty:(string|undefined)}}
 */
ui.cmp.DataViewController.Config;

/**
 * @typedef {{fromRaw:(function(?):?), toRaw:(function(?):?)}}
 */
ui.cmp.DataViewController.Converter;

/**
 * @private
 * @param {string} baseAttrName
 * @param {!angular.Attributes} $attrs
 * @return {{expression:?string, variable:?string}}
 */
ui.cmp.DataViewController.prototype._parseInstanceConfig = function(baseAttrName, $attrs) {
    var m = /^(.*?)(?:\s*\bas\s+(\S+))?$/.exec($attrs[baseAttrName]);
    return {
        expression: (m && m[1] || null),
        variable: (m && m[2] || null)
    };
};

/**
 * @private
 * @param {?string} instanceExpression
 * @param {!angular.$parse} $parse
 * @return {!angular.$parse.Expression}
 */
ui.cmp.DataViewController.prototype._createInputExpression = function(instanceExpression, $parse) {
    if (instanceExpression) {
        return $parse(instanceExpression);
    }
    return function(scope) {
        return undefined;
    };
};

/**
 * @private
 * @param {string} baseAttrName
 * @param {string} optionalAttrName
 * @param {!angular.Attributes} $attrs
 * @param {!angular.$parse} $parse
 * @return {?angular.$parse.Expression}
 */
ui.cmp.DataViewController.prototype._createOptionalExpression = function(baseAttrName, optionalAttrName, $attrs, $parse) {
    var exprString = $attrs[baseAttrName + optionalAttrName];
    if (exprString) {
        return $parse(exprString);
    }
    return null;
};

/**
 * @private
 * @param {!Object<string,!ui.cmp.DataViewController.Converter>|undefined} converters
 * @return {{count:number, map:!Object<string,!ui.cmp.DataViewController.Converter>, list:!Array<{propertyName:string,
 *         converter:!ui.cmp.DataViewController.Converter}>}}
 */
ui.cmp.DataViewController.prototype._createConversions = function(converters) {
    var conversions = {
        count: 0,
        map: {},
        list: []
    };
    if (converters) {
        Object.keys(converters).forEach(function(propertyName) {
            var conv = converters[propertyName];
            conversions.map[propertyName] = conv;
            conversions.list.push({
                propertyName: propertyName,
                converter: conv
            });
            conversions.count++;
        });
    }
    return conversions;
};

/**
 * @private
 * @param {?Array|?Object} data
 * @param {!Error=} error
 */
ui.cmp.DataViewController.prototype._publishState = function(data, error) {
    var loading = (data === null && !error);
    this.ready = (!loading && !error);
    this.loading = loading;
    if (!loading) {
        this.data = data;
    }
    this.error = (error ? error.message : null);
    ui.applyScope(this._scope);
};

/**
 * @param {boolean=} nonInteractive
 * @return {!Promise}
 */
ui.cmp.DataViewController.prototype.refresh = function(nonInteractive) {

    /* Do paging LOCALLY if using a local filter */
    var useLocalPaging = !!this._filterExpr;

    this._uiActivity.startActivity();
    return Promise.resolve().then(function() {
        var inputData = this._inputExpr(this._scope);

        /* Query the data */
        var query = new rest.data.Query(this._queryFilter, this._querySorting, useLocalPaging ? null : this._queryPaging);
        var dataOrPromise = this._fetchData(inputData, query);
        if (ui.isPromise(dataOrPromise) && !nonInteractive) {
            this._publishState(null);
        }
        return dataOrPromise;

    }.bind(this)).then(function(data) {

        /* Filter the resulting data locally */
        return this._filterFetchedData(data, useLocalPaging ? this._queryPaging : null);

    }.bind(this)).then(function(data) {
        this._publishState(data);
        return data;
    }.bind(this), function(e) {
        this._publishState(null, /** @type {!Error} */
        (e));
    }.bind(this)).then(function(data) {

        /* Finish the refresh always (even in case of errors) */
        this._refreshedFetchedData(data);
        this._scope.$broadcast("uiDataViewRefreshed", this);
        this._uiActivity.stopActivity();
        return data;
    }.bind(this));
};

/**
 * @private
 * @param {!Object} data
 * @return {undefined}
 */
ui.cmp.DataViewController.prototype._refreshedFetchedData = function(data) {
    /* Call the refreshed function */
    if (!this._refreshedFn) {
        return;
    }
    this._refreshedFn(this._scope, {
        "data": data
    });
}

/**
 * @private
 * @param {!Array|!Object} data
 * @param {?rest.data.Paging} paging
 * @return {!Array|?Object}
 */
ui.cmp.DataViewController.prototype._filterFetchedData = function(data, paging) {
    if (!this._filterExpr && this._conversions.count <= 0 && !paging) {
        return data;
    }

    var isArray = Array.isArray(data);
    var dataArray = /** @type {!Array} */
    (isArray ? data : [ data ]);
    var metadata = isArray ? rest.data.ResultSet.extractMetadata(dataArray) : null;
    var originalMetadata = metadata;

    /* Apply the filter expression */
    if (this._filterExpr) {
        dataArray = dataArray.filter(function(row) {
            return !!this._filterExpr(this._scope, {
                "row": row
            });
        }, this);
    }

    /* Convert the properties */
    if (this._conversions.count > 0) {
        dataArray.forEach(function(row) {
            this._conversions.list.forEach(function(conv) {
                var rawValue = row[conv.propertyName];
                if (rawValue !== undefined) {
                    row[conv.propertyName] = conv.converter.fromRaw(rawValue);
                }
            }, this);
        }, this);
    }

    /* Apply paging */
    if (paging) {
        var pagedDataArray = new rest.data.Processor(dataArray).scroll(paging);
        var pagedMetadata = rest.data.ResultSet.extractMetadata(pagedDataArray);
        dataArray = pagedDataArray;
        metadata = new rest.data.Metadata(pagedMetadata.getTotalCount(), new rest.data.Query(metadata.getQuery().getFilter(),
                metadata.getQuery().getSorting(), pagedMetadata.getQuery().getPaging()));
    }

    /* Enrich with the tracking values */
    if (this._trackingProperty) {
        dataArray.forEach(function(row) {
            row["$$hashKey"] = row[this._trackingProperty];
        }, this);
    }

    if (isArray) {
        if (metadata && metadata !== originalMetadata) {
            return new rest.data.ResultSet(dataArray, metadata, 200);
        }
        return dataArray;
    }
    return (dataArray.length > 0 ? dataArray[0] : null);
};

/**
 * @internal
 * @return {?rest.data.Metadata}
 */
ui.cmp.DataViewController.prototype.getPublishedMetadata = function() {
    if (this.data && Array.isArray(this.data)) {
        return rest.data.ResultSet.extractMetadata(/** @type {!Array} */
        (this.data));
    }
    return null;
};

/**
 * @internal
 * @param {?rest.data.filter.Expression} filter
 */
ui.cmp.DataViewController.prototype.setQueryFilter = function(filter) {
    if (filter && this._conversions.count > 0) {
        filter = this._convertExpression(filter);
    }
    this._queryFilter = filter;
    if (this._queryPaging) {
        this._queryPaging = new rest.data.Paging(1, this._queryPaging.getPageSize());
    }
};

/**
 * @private
 * @param {!rest.data.filter.Expression} expression
 * @return {!rest.data.filter.Expression}
 */
ui.cmp.DataViewController.prototype._convertExpression = function(expression) {
    if (expression instanceof rest.data.filter.Term) {
        return this._convertTerm(expression);
    }
    return this._convertCompound(/** @type {!rest.data.filter.Compound} */
    (expression));
};

/**
 * @private
 * @param {!rest.data.filter.Compound} compound
 * @return {!rest.data.filter.Compound}
 */
ui.cmp.DataViewController.prototype._convertCompound = function(compound) {
    return new rest.data.filter.Compound(compound.getOperator(), compound.getOperands().map(function(operand) {
        return this._convertExpression(operand);
    }, this));
};

/**
 * @private
 * @param {!rest.data.filter.Term} term
 * @return {!rest.data.filter.Term}
 */
ui.cmp.DataViewController.prototype._convertTerm = function(term) {
    var conv = this._conversions.map[this.getPropertyViewName(term.getProperty())];
    if (!conv) {
        return term; // no conversion
    }
    return new rest.data.filter.Term(term.getOperator(), term.getProperty(), term.getValues().map(conv.toRaw));
};

/**
 * @internal
 * @param {!Array<!rest.data.SortCriterion>} sorting
 */
ui.cmp.DataViewController.prototype.setQuerySorting = function(sorting) {
    this._querySorting = sorting;
};

/**
 * @internal
 * @param {?rest.data.Paging} paging
 */
ui.cmp.DataViewController.prototype.setQueryPaging = function(paging) {
    this._queryPaging = paging;
};

/**
 * @internal
 * @param {string} viewName
 * @return {!rest.data.Ref}
 */
ui.cmp.DataViewController.prototype.getPropertyRef = function(viewName) {
    if (viewName in this._references) {
        return this._references[viewName];
    }
    return new rest.data.NameRef(viewName);
};

/**
 * @internal
 * @param {!rest.data.Ref} ref
 * @return {string}
 */
ui.cmp.DataViewController.prototype.getPropertyViewName = function(ref) {
    if (ref instanceof rest.data.NameRef) {
        return ref.getName();
    }
    throw new Error("Unsupported reference type in data view");
};

/**
 * @package
 * @param {!angular.JQLite} $element
 * @param {string} errorLabel
 * @return {!ui.cmp.DataViewController}
 */
ui.cmp.DataViewController.locate = function($element, errorLabel) {
    var definedNames = ui.cmp.dataViewDirectiveFactory.getDefinedNames();

    /*
     * Traverse the DOM by looking for the closest ancestor that has one of the directives know to use a DataViewController. This
     * cannot be done statically using the directive definition object because the possible ancestor directives can be extended
     */
    for (var current = $element; !!current[0]; current = current.parent()) {
        var ctrl = null;
        definedNames.forEach(function(definedName) {
            var foundCtrl = current.controller(definedName);
            if (foundCtrl) {
                if (foundCtrl._element[0] !== current[0]) {
                    return; // continue, the controller is on an ancestor
                }
                if (ctrl) {
                    throw new Error("Found multiple parents for the " + errorLabel);
                } else {
                    ctrl = foundCtrl;
                }
            }
        });
        if (ctrl) {
            return ctrl;
        }
    }

    throw new Error("The " + errorLabel + " must be placed inside one of the following directives: " + definedNames.join(", "));
};




//== ui/cmp/dataViewDirectiveFactory.js =======================================

/**
 * @param {!ui.cmp.DataViewController.Config} config
 * @return {!angular.Directive}
 */
ui.cmp.dataViewDirectiveFactory = function(config) {

    /* Keep track of the defined directives */
    ui.cmp.dataViewDirectiveFactory._definedNames.push(config.directiveName);

    /**
     * @ngInject
     * @param {!angular.Scope} $scope
     * @param {!angular.JQLite} $element
     * @param {!angular.Attributes} $attrs
     * @param {!angular.$injector} $injector
     */
    function Controller($scope, $element, $attrs, $injector) {
        return $injector.instantiate(ui.cmp.DataViewController, {
            "$scope": $scope,
            "$element": $element,
            "$attrs": $attrs,
            "config": config
        });
    }

    return (/** @type {!angular.Directive} */
    ({
        restrict: "AE",
        scope: true,
        controller: Controller
    }));
};

/**
 * @private
 * @type {!Array<string>}
 */
ui.cmp.dataViewDirectiveFactory._definedNames = [];

/**
 * @return {!Array<string>}
 */
ui.cmp.dataViewDirectiveFactory.getDefinedNames = function() {
    return this._definedNames;
};




//== ui/cmp/FilterController.js ===============================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.JQLite} $element
 */
ui.cmp.FilterController = function($element) {

    /** @private */
    this._dataViewCtrl = this._dataViewCtrl = ui.cmp.DataViewController.locate($element, "filter directive");

    /* Filtering state */

    /**
     * @private
     * @type {!Object<string,string|!Object<string,string>>}
     */
    this.cond = {};
};

/**
 * @return {!Promise}
 */
ui.cmp.FilterController.prototype.apply = function() {
    this._dataViewCtrl.setQueryFilter(this._constructExpression());
    return this._dataViewCtrl.refresh();
};

/**
 * @return {!Promise}
 */
ui.cmp.FilterController.prototype.reset = function() {
    this.cond = {};
    return this.apply();
};

/**
 * @const {!Object<string,!rest.data.filter.Operator>}
 */
ui.cmp._OPERATOR_KEYS = (function() {
    var Operator = rest.data.filter.Operator;
    var map = {};
    map["equal"] = Operator.EQUAL;
    map["notEqual"] = Operator.NOT_EQUAL;
    map["greater"] = Operator.GREATER;
    map["greaterOrEqual"] = Operator.GREATER_OR_EQUAL;
    map["empty"] = Operator.EMPTY;
    map["notEmpty"] = Operator.NOT_EMPTY;
    map["lesser"] = Operator.LESSER;
    map["lesserOrEqual"] = Operator.LESSER_OR_EQUAL;
    map["begins"] = Operator.BEGINS_WITH;
    map["notBegins"] = Operator.NOT_BEGINS_WITH;
    map["contains"] = Operator.CONTAINS;
    map["notContains"] = Operator.NOT_CONTAINS;
    map["ends"] = Operator.ENDS_WITH;
    map["notEnds"] = Operator.NOT_ENDS_WITH;
    return map;
})();

/**
 * @private
 * @return {?rest.data.filter.Expression}
 */
ui.cmp.FilterController.prototype._constructExpression = function() {

    /* Construct all terms */
    var terms = [];
    Object.keys(this.cond).forEach(function(property) {
        var propertyRef = this._dataViewCtrl.getPropertyRef(property);
        terms = terms.concat(ui.cmp.FilterController._constructTerms(propertyRef, this.cond[property]));
    }, this);

    /* With one or more term, construct an expression; use an "and" compound if there are two or more terms */
    if (terms.length > 1) {
        return new rest.data.filter.Compound(rest.data.filter.LogicOperator.AND, terms);
    } else if (terms.length > 0) {
        return terms[0];
    }

    /* Zero terms, nothing to filter */
    return null;
};

/**
 * @private
 * @param {!rest.data.Ref} propertyRef
 * @param {string|!Object<string,string>} condElement
 * @return {!Array<!rest.data.filter.Term>}
 */
ui.cmp.FilterController._constructTerms = function(property, condElement) {
    var terms = [];

    function addTerm(operator, property, value) {
        if (value === undefined || value === null || value === "") {
            return;
        }
        terms.push(new rest.data.filter.Term(operator, property, value));
    }

    if (typeof condElement !== "object" || Array.isArray(condElement)) {

        /* Treat the lone string condition element as an "equal" condition */
        addTerm(rest.data.filter.Operator.EQUAL, property, condElement);

    } else {

        /* Add a term for each operator key */
        Object.keys(condElement).forEach(function(key) {
            var operator = ui.cmp._OPERATOR_KEYS[key];
            if (!operator) {
                throw new Error("Unknown condition operator for '" + key + "'");
            }
            addTerm(operator, property, condElement[key]);
        });
    }

    return terms;
};




//== ui/cmp/filterDirective.js ================================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.filterDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",
        scope: true,
        controller: ui.cmp.FilterController,
        controllerAs: "filter"
    }));
};



//== ui/cmp/ScrollerController.js =============================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.Scope} $scope
 * @param {!angular.JQLite} $element
 * @param {!angular.Attributes} $attrs
 */
ui.cmp.ScrollerController = function($scope, $element, $attrs) {

    /** @private */
    this._dataViewCtrl = ui.cmp.DataViewController.locate($element, "scroller directive");

    /** @private */
    this._scope = $scope;

    /* Scrolling state */

    /** @private */
    this._pageSize = Number($attrs["uiScrollerPageSize"] || "10");

    /** @private */
    this._currentPage = 1;

    /** @private */
    this._totalPages = 1;

    /**
     * @private
     * @type {!Array<number>}
     */
    this._pages = [];

    /* Publish read-only properties for the scrolling state */
    Object.defineProperties(this, {
        "currentPage": {
            get: function() {
                return this._currentPage;
            }
        },
        "totalPages": {
            get: function() {
                return this._totalPages;
            }
        },
        "pages": {
            get: function() {
                return this._pages;
            }
        },
        "atFirst": {
            get: function() {
                return this._currentPage <= 1;
            }
        },
        "atLast": {
            get: function() {
                return this._currentPage >= this._totalPages;
            }
        }
    });

    /* Publish metadata each time the data view is refreshed */
    this._scope.$on("uiDataViewRefreshed", function(event, dataViewCtrl) {
        if (dataViewCtrl !== this._dataViewCtrl) {
            return; // ignore events from unrelated data views
        }
        this._publishMetadata(dataViewCtrl.getPublishedMetadata());
    }.bind(this));

    /* Set the paging eagerly, so that the data view will use it from the first request */
    this._dataViewCtrl.setQueryPaging(this._constructPaging());
};

/**
 * @return {!Promise}
 */
ui.cmp.ScrollerController.prototype.moveFirst = function() {
    return this.moveTo(1);
};

/**
 * @return {!Promise}
 */
ui.cmp.ScrollerController.prototype.movePrevious = function() {
    return this.moveTo(this._currentPage - 1);
};

/**
 * @return {!Promise}
 */
ui.cmp.ScrollerController.prototype.moveNext = function() {
    return this.moveTo(this._currentPage + 1);
};

/**
 * @return {!Promise}
 */
ui.cmp.ScrollerController.prototype.moveLast = function() {
    return this.moveTo(this._totalPages);
};

/**
 * @param {number} page
 * @return {!Promise}
 */
ui.cmp.ScrollerController.prototype.moveTo = function(page) {

    /* Change page, ensuring that the number falls into the correct range */
    page = Math.max(1, Math.min(page, this._totalPages));
    if (page !== this._currentPage) {
        this._currentPage = page;
        return this._apply();
    }

    /* Avoid applying when the page stays the same */
    return Promise.resolve();
};

/**
 * @private
 * @param {?rest.data.Metadata} metadata
 */
ui.cmp.ScrollerController.prototype._publishMetadata = function(metadata) {
    var totalCount = metadata && metadata.getTotalCount();
    var paging = metadata && metadata.getQuery().getPaging();

    /* Compute the current page and the total page number; use sound defaults when no information is available */
    var currentPage, totalPages;
    if (totalCount !== null && paging) {
        currentPage = paging.getPageNumber();
        totalPages = Math.ceil(totalCount / paging.getPageSize());
    } else {
        currentPage = 1;
        totalPages = 1;
    }

    /* Define the visible window of pages */
    var pages = new Array(totalPages);
    for (var i = 1; i <= totalPages; i++) {
        pages[i - 1] = i;
    }
    this._pages = pages;
    this._totalPages = totalPages;
    this._currentPage = currentPage;
};

/**
 * @private
 * @return {!Promise}
 */
ui.cmp.ScrollerController.prototype._apply = function() {
    this._dataViewCtrl.setQueryPaging(this._constructPaging());
    return this._dataViewCtrl.refresh();
};

/**
 * @private
 * @return {!rest.data.Paging}
 */
ui.cmp.ScrollerController.prototype._constructPaging = function() {
    return new rest.data.Paging(this._currentPage, this._pageSize);
};




//== ui/cmp/scrollerDirective.js ==============================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.scrollerDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",
        scope: true,
        controller: ui.cmp.ScrollerController,
        controllerAs: "scroller"
    }));
};



//== ui/cmp/SorterController.js ===============================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.Scope} $scope
 * @param {!angular.JQLite} $element
 * @param {!angular.Attributes} $attrs
 */
ui.cmp.SorterController = function($scope, $element, $attrs) {

    /** @private */
    this._dataViewCtrl = ui.cmp.DataViewController.locate($element, "sorter directive");

    /** @private */
    this._scope = $scope;

    /** @private */
    this._historySize = Number($attrs["uiSorterHistory"] || "1");

    /* Sorting state */

    /**
     * @private
     * @type {!Object<string,!ui.cmp.SorterController._Criterion>}
     */
    this._criteria = {};

    /**
     * @private
     * @type {!Array<string>}
     */
    this._criteriaOrder = [];

    /* Publish criteria as a read-only property */
    Object.defineProperty(this, "criteria", {
        get: function() {
            return this._criteria
        }.bind(this)
    });

    /* Publish metadata each time the data view is refreshed */
    this._scope.$on("uiDataViewRefreshed", function(event, dataViewCtrl) {
        if (dataViewCtrl !== this._dataViewCtrl) {
            return; // ignore events from unrelated data views
        }
        this._publishMetadata(dataViewCtrl.getPublishedMetadata());
    }.bind(this));

    /* Set the initial sorting, setting it eagerly on the data view for using it from the first request */
    if ($attrs["uiSorterInitial"]) {
        this._applySortingExpression($attrs["uiSorterInitial"]);
        this._dataViewCtrl.setQuerySorting(this._constructCriteria());
    }
};

/**
 * @param {string} sortingExpressino
 */
ui.cmp.SorterController.prototype._applySortingExpression = function(sortingExpressino) {
    this._criteria = {};
    this._criteriaOrder = sortingExpressino.split(/\s*,\s*/).map(function(critExpression) {
        var m = /^(?:\s*(-))?\s*(.*?)\s*$/.exec(critExpression);
        var crit = new ui.cmp.SorterController._Criterion();
        crit.descending = !!m[1];
        var property = m[2];
        this._criteria[property] = crit;
        return property;
    }, this);
};

/**
 * @param {string} property
 */
ui.cmp.SorterController.prototype.toggle = function(property) {

    /* Reorder criteria with the toggled one at the end */
    var oldIndex = this._criteriaOrder.indexOf(property);
    if (oldIndex >= 0) {
        this._criteriaOrder.splice(oldIndex, 1);
    }
    this._criteriaOrder.push(property);
    while (this._criteriaOrder.length > this._historySize) {
        var removedProperty = this._criteriaOrder.shift();
        if (removedProperty !== property) {
            this._getPublishedCriterion(removedProperty).descending = null;
        }
    }

    /* If already set, toggle the direction, otherwise set to ascending */
    var crit = this._getPublishedCriterion(property);
    if (crit.descending !== null) {
        crit.descending = !crit.descending;
    } else {
        crit.descending = false;
    }
};

/**
 * @private
 * @param {?rest.data.Metadata} metadata
 */
ui.cmp.SorterController.prototype._publishMetadata = function(metadata) {
    var sorting = metadata ? metadata.getQuery().getSorting() : [];

    /* Null out all existing published criteria */
    Object.keys(this._criteria).forEach(function(property) {
        this._criteria[property].descending = null;
    }, this);

    /* Set the direction and order of some criteria as indicated by the server */
    this._criteriaOrder = sorting.map(function(sortingCrit) {
        var property = this._dataViewCtrl.getPropertyViewName(sortingCrit.getProperty());
        var crit = this._getPublishedCriterion(property);
        crit.descending = sortingCrit.isDescending();
        return property;
    }, this);
};

/**
 * @private
 * @param {string} property
 * @return {!ui.cmp.SorterController._Criterion}
 */
ui.cmp.SorterController.prototype._getPublishedCriterion = function(property) {
    var crit = this._criteria[property];
    if (!crit) {
        this._criteria[property] = crit = new ui.cmp.SorterController._Criterion();
    }
    return crit;
};

/**
 * @return {!Promise}
 */
ui.cmp.SorterController.prototype.apply = function() {
    this._dataViewCtrl.setQuerySorting(this._constructCriteria());
    return this._dataViewCtrl.refresh();
};

/**
 * @private
 * @return {!Array<!rest.data.SortCriterion>}
 */
ui.cmp.SorterController.prototype._constructCriteria = function() {
    var result = [];
    this._criteriaOrder.forEach(function(property) {
        var descending = this._criteria[property].descending;
        if (descending !== null) {
            var propertyRef = this._dataViewCtrl.getPropertyRef(property);
            result.push(new rest.data.SortCriterion(propertyRef, descending));
        }
    }, this);
    return result;
};

/*
 * Criterion (published in scope)
 */

/**
 * @constructor
 */
ui.cmp.SorterController._Criterion = function() {

    /** @type {?boolean} */
    this.descending = null;
};

Object.defineProperty(ui.cmp.SorterController._Criterion.prototype, "ascending",
        /** @lends {ui.cmp.SorterController._Criterion.prototype} */
({
    get: function() {
        if (this.descending === null) {
            return null;
        }
        return !this.descending;
    }
}));




//== ui/cmp/sorterDirective.js ================================================

/**
 * @ngInject
 * @return {!angular.Directive}
 */
ui.cmp.sorterDirective = function() {
    return (/** @type {!angular.Directive} */
    ({
        restrict: "A",
        scope: true,
        controller: ui.cmp.SorterController,
        controllerAs: "sorter"
    }));
};



//== ui/ctrl/HistoricProcessDetails.js ========================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.$routeParams} $routeParams
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.StorageService} uiStorage
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.HistoricProcessDetails = function($routeParams, uiBackEnd, uiStorage, uiAlerter, uiDialog, $rootScope, $location, $log) {

    /**
     * @const {number}
     */
    this.processId = Number($routeParams["processId"]);

    /** @private */
    this._uiBackEnd = uiBackEnd;

    /** @private */
    this._uiStorage = uiStorage;

    /**
     * @param {!Object} process
     * @return {undefined}
     */
    this.prefillForm = function(process) {
        this.oid = process["oid"];
        if (this.oid !== this.processId) {
            throw new Error("Invalid oid " + this.oid + ". Expected " + this.processId);
        }
        this.status = process["status"];

        // retrieve processDefinition, catchingEventsByTaskId and involvedUsers
        uiBackEnd.retrieveProcessDefinition(process["definition"]["id"]).then(function(data) {
            this.processDefinition = data;
            return this.updateCache();
        }.bind(this), function(e) {
            $log.error("Missing");
            throw e;
        }.bind(this));

    };

    /**
     * @return {!Promise}
     */
    this.updateCache = function() {
        return uiBackEnd.listHistoricProcessTasks(this.processId, null).then(function(data) {
            var tempMap = {};
            var usernames = {};// only for string!
            data.forEach(function(task) {
                usernames[task["user"]] = true;
                var messageIds = [];
                task["definition"]["catchingMessages"].forEach(function(msgId) {
                    messageIds.push(msgId);
                }, this);
                tempMap[task["oid"]] = messageIds;
            }, this);
            this.catchingEventsByTaskId = tempMap;
            return usernames;
        }.bind(this)).then(function(usernames) {
            return uiBackEnd.listUsers(null).then(function(data) {
                var list = [];
                data.forEach(function(user) {
                    if (usernames[user["username"]]) {
                        list.push(user);
                    }
                }, this);
                this.involvedUsers = list;
            }.bind(this));
        }.bind(this));
    }

    /**
     * @param {!function()=} otherRefreshFn
     * @return {undefined}
     */
    this.refresh = function(otherRefreshFn) {
        this.updateCache().then(function() {
            if (otherRefreshFn) {
                otherRefreshFn();
            }
        }.bind(this));
    }

    /**
     * @return {!Promise}
     */
    this.toggleProcessStatus = function() {
        if (!this.oid || !this.status) {
            $log.error("Missing");
            return Promise.resolve();
        }
        // TODO
        return Promise.resolve().then(function() {
            alert("TODO 'Suspend/Activate' for process " + this.oid + " with status " + this.status);

        }.bind(this))
    };

    /**
     * @return {!Promise}
     */
    this.deleteProcess = function() {
        if (!this.oid) {
            $log.error("Missing");
            return Promise.resolve();
        }
        // TODO
        return Promise.resolve().then(function() {
            alert("TODO 'Delete' process " + this.oid);

        }.bind(this))
    };

    /**
     * @return {!Promise}
     */
    this.rollbackToTask = function() {
        if (!this.oid) {
            $log.error("Missing");
            return Promise.resolve();
        }
        // TODO
        return Promise.resolve().then(function() {
            alert("TODO 'Rollback' process " + this.oid);

        }.bind(this))
    };

    /**
     * @param {!string} fileId
     * @param {!string} fileName
     * @return {!Promise}
     */
    this.downloadAttachment = function(fileId, fileName) {
        return uiBackEnd.downloadFile(fileId).then(function(blob) {
            saveAs(blob, fileName, true);
        }.bind(this));
    }

    /**
     * @param {!Object} task
     * @return {boolean}
     */
    this.canSendMessage = function(task) {
        if (!this.oid) { // dont'log!
            return false;
        }
        return task && (task["status"] === "READY" || task["status"] === "ACTIVE") && (this.catchingEventsByTaskId[task["oid"]]
                !== undefined) && (this.catchingEventsByTaskId[task["oid"]].length > 0);
    };

    /**
     * @param {!Object} task
     * @return {boolean}
     */
    this.canRetry = function(task) {
        if (!this.oid) { // dont'log!
            return false;
        }
        return (task && (task["definition"]["type"] === "ServiceTask") && (task["status"] === "ABORTED"));
    };

    /**
     * @param {!Object} task
     * @return {boolean}
     */
    this.canReassign = function(task) {
        if (!this.oid) { // dont'log!
            return false;
        }
        return (task && (task["definition"]["type"] === "UserTask") && (task["status"] === "READY" || task["status"] === "ACTIVE"));
    };

    /* Page state variables */

    /** @type {?number} */
    this.oid = null;

    /** @type {?string} */
    this.status = null;

    /** @type {?Object} */
    this.processDefinition = null;

    /** @type {!Object<string,Array<string>>} */
    this.catchingEventsByTaskId = {};

    /** @type {!Array<string>} */
    this.involvedUsers = [];

};

/**
 * @package
 * @const {string}
 */
ui.ctrl.HistoricProcessDetails.VIEW_NAME = "historicProcessDetails";

/**
 * @package
 * @const {string}
 */
ui.ctrl.HistoricProcessDetails.VIEW_PARAM = "processId";




//== ui/ctrl/Login.js =========================================================

/**
 * @constructor
 * @ngInject
 * @param {string} nextPath
 * @param {!ui.AuthService} uiAuth
 * @param {!ui.AlerterService} uiAlerter
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.Login = function(nextPath, uiAuth, uiAlerter, $rootScope, $location, $log) {

    /**
     * @return {!Promise}
     */
    this.login = function() {
        if (!this.username || !this.password) {
            $log.error("Missing");
            return Promise.resolve();
        }

        return uiAuth.login(this.username, this.password).then(function() {
            $log.debug("Logged in, redirecting to original destination");
            uiAlerter.showInfo("You have been logged in");
            $location.path(nextPath || "/home");
            ui.applyScope($rootScope);
        }.bind(this), function(e) {
            $log.debug("Login failed");
            uiAlerter.showError(e.message);
        }.bind(this));
    };

    /* Page state variables */

    /** @type {?string} */
    this.username = null;

    /** @type {?string} */
    this.password = null;
};




//== ui/ctrl/ProcessDefinitionDetails.js ======================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.$routeParams} $routeParams
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.StorageService} uiStorage
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.ProcessDefinitionDetails = function($routeParams, uiBackEnd, uiStorage, uiAlerter, uiDialog, $rootScope, $location, $log) {

    /**
     * @const {string}
     */
    this.processDefinitionId = String($routeParams["processDefinitionId"]);

    /** @private */
    this._uiBackEnd = uiBackEnd;

    /** @private */
    this._uiStorage = uiStorage;

    /**
     * @param {!Object} processDefinition
     * @return {undefined}
     */
    this.prefillForm = function(processDefinition) {
        this.definitionId = processDefinition["definitionId"];
        this.definitionModelId = processDefinition["modelId"];
        if (this.definitionId !== this.processDefinitionId) {
            throw new Error("Invalid oid " + this.definitionId + ". Expected " + this.processDefinitionId);
        }

    };

    /* Page state variables */

    /** @type {?string} */
    this.definitionId = null;

    /** @type {?Object} */
    this.processDefinition = null;

    /** @type {?string} */
    this.definitionModelId = null;
};

/**
 * @package
 * @const {string}
 */
ui.ctrl.ProcessDefinitionDetails.VIEW_NAME = "processDefinitionDetails";

/**
 * @package
 * @const {string}
 */
ui.ctrl.ProcessDefinitionDetails.VIEW_PARAM = "processDefinitionId";




//== ui/ctrl/ProcessDetails.js ================================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.$routeParams} $routeParams
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.StorageService} uiStorage
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.ProcessDetails = function($routeParams, uiBackEnd, uiStorage, uiAlerter, uiDialog, $rootScope, $location, $log) {

    /**
     * @const {number}
     */
    this.processId = Number($routeParams["processId"]);

    /** @private */
    this._uiBackEnd = uiBackEnd;

    /** @private */
    this._uiStorage = uiStorage;

    /**
     * @param {!Object} process
     * @return {undefined}
     */
    this.prefillForm = function(process) {
        this.oid = process["oid"];
        if (this.oid !== this.processId) {
            throw new Error("Invalid oid " + this.oid + ". Expected " + this.processId);
        }
        this.status = process["status"];

        // retrieve processDefinition, catchingEventsByTaskId and involvedUsers
        uiBackEnd.retrieveProcessDefinition(process["definition"]["id"]).then(function(data) {
            this.processDefinition = data;
            return this.updateCache();
        }.bind(this), function(e) {
            $log.error("Missing");
            throw e;
        }.bind(this));

    };

    /**
     * @return {!Promise}
     */
    this.updateCache = function() {
        return uiBackEnd.listProcessTasks(this.processId, null).then(function(data) {
            var tempMap = {};
            var usernames = {};// only for string!
            data.forEach(function(task) {
                usernames[task["user"]] = true;
                var messageIds = [];
                task["definition"]["catchingMessages"].forEach(function(msgId) {
                    messageIds.push(msgId);
                }, this);
                tempMap[task["oid"]] = messageIds;
            }, this);
            this.catchingEventsByTaskId = tempMap;
            return usernames;
        }.bind(this)).then(function(usernames) {
            return uiBackEnd.listUsers(null).then(function(data) {
                var list = [];
                data.forEach(function(user) {
                    if (usernames[user["username"]]) {
                        list.push(user);
                    }
                }, this);
                this.involvedUsers = list;
            }.bind(this));
        }.bind(this));
    }

    /**
     * @param {!function()=} otherRefreshFn
     * @return {undefined}
     */
    this.refresh = function(otherRefreshFn) {
        this.updateCache().then(function() {
            if (otherRefreshFn) {
                otherRefreshFn();
            }
        }.bind(this));
    }

    /**
     * @return {!Promise}
     */
    this.toggleProcessStatus = function() {
        if (!this.oid || !this.status) {
            $log.error("Missing");
            return Promise.resolve();
        }
        var action;
        if (this.status === "SUSPENDED") {
            action = "RESUME";
        } else if (this.status === "ACTIVE") {
            action = "SUSPEND";
        } else {
            throw new Error("Unexpected status: " + this.status);
        }
        return this._uiBackEnd.performedProcessAction(this.oid, action).then(function() {
            if (DEBUG) {
                $log.debug("Performed process action '" + action + "'");
            }
            ui.applyScope($rootScope);
            $rootScope.$broadcast("uiDataFamilyUpdated", "processes");
        }.bind(this), function(e) {
            if (DEBUG) {
                $log.debug("Performed process action '" + action + "' failed");
            }
            uiAlerter.showError(e.message);
        }.bind(this));
    };

    /**
     * @return {!Promise}
     */
    this.deleteProcess = function() {
        if (!this.oid || !this.status) {
            $log.error("Missing");
            return Promise.resolve();
        }
        var action;
        if (this.status === "ACTIVE" || this.status === "SUSPENDED") {
            action = "CANCEL";
        } else {
            throw new Error("Unexpected status: " + this.status);
        }
        return this._uiBackEnd.performedProcessAction(this.oid, action).then(function() {
            if (DEBUG) {
                $log.debug("Performed process action '" + action + "'");
            }
            ui.applyScope($rootScope);
            $rootScope.$broadcast("uiDataFamilyUpdated", "processes");
        }.bind(this), function(e) {
            if (DEBUG) {
                $log.debug("Performed process action '" + action + "' failed");
            }
            uiAlerter.showError(e.message);
        }.bind(this));
    };

    /**
     * @return {!Promise}
     */
    this.rollbackToTask = function() {
        if (!this.oid) {
            $log.error("Missing");
            return Promise.resolve();
        }
        // TODO
        return Promise.resolve().then(function() {
            alert("TODO 'Rollback' process " + this.oid);

        }.bind(this))
    };

    /**
     * @param {!number} taskId
     * @return {undefined}
     */
    this.reassignTask = function(taskId) {
        if (!this.oid) {
            $log.error("Missing");
            return;
        }
        uiDialog.showDialog({
            templateUrl: "dialogs/reassignCandidateUsersAndRoles.html",
            controller: ui.ctrl.ReassignCandidateUsersAndRoles,
            data: {
                "inputDialog": {

                    "taskId": taskId
                }
            }
        }).then(function(result) {
            if (result.dismissed) {
                return;
            }
            var ctrl = result.value;
            if (!ctrl) {
                return;
            }
            if (ctrl.user) {
                return this._uiBackEnd.updateTaskUser(taskId, ctrl.user["oid"]).then(function() {
                    $log.debug("Reassigned user");
                }.bind(this), function(e) {
                    $log.debug("Reassigned user failed");
                    uiAlerter.showError(e.message);
                }.bind(this));
            }
            if (ctrl.role) {
                return this._uiBackEnd.updateTaskRole(taskId, ctrl.role).then(function() {
                    $log.debug("Reassigned role");
                }.bind(this), function(e) {
                    $log.debug("Reassigned role failed");
                    uiAlerter.showError(e.message);
                }.bind(this));
            }
            throw new Error("Unexpected state: required user or role");
        }.bind(this));

    };

    /**
     * @param {!number} taskId
     * @return {!Promise}
     */
    this.retryTask = function(taskId) {
        if (!this.oid) {
            $log.error("Missing");
            return Promise.resolve();
        }
        return this._uiBackEnd.updateTaskAction(taskId, "RETRY").then(function() {
            $log.debug("Retried task action");
            ui.applyScope($rootScope);
        }.bind(this), function(e) {
            $log.debug("Retried task action failed");
            uiAlerter.showError(e.message);
        }.bind(this));
    };

    /**
     * @param {!string} taskId
     * @return {undefined}
     */
    this.sendMessage = function(taskId) {
        if (!this.oid) {
            $log.error("Missing");
            return;
        }

        uiDialog.showDialog({
            templateUrl: "dialogs/setRunningProcessParameters.html",
            controller: ui.ctrl.SetRunningProcessParameters,
            data: {
                "processId": this.oid,

                "processDefinition": this.processDefinition

            }
        });

    };

    /**
     * @param {!string} fileId
     * @param {!string} fileName
     * @return {!Promise}
     */
    this.downloadAttachment = function(fileId, fileName) {
        return uiBackEnd.downloadFile(fileId).then(function(blob) {
            saveAs(blob, fileName, true);
        }.bind(this));
    }

    /**
     * @param {!Object} task
     * @return {boolean}
     */
    this.canSendMessage = function(task) {
        if (!this.oid) { // dont'log!
            return false;
        }
        return task && (task["status"] === "READY" || task["status"] === "ACTIVE") && (this.catchingEventsByTaskId[task["oid"]]
                !== undefined) && (this.catchingEventsByTaskId[task["oid"]].length > 0);
    };

    /**
     * @param {!Object} task
     * @return {boolean}
     */
    this.canRetry = function(task) {
        if (!this.oid) { // dont'log!
            return false;
        }
        return (task && (task["definition"]["type"] === "ServiceTask") && (task["status"] === "ABORTED"));
    };

    /**
     * @param {!Object} task
     * @return {boolean}
     */
    this.canReassign = function(task) {
        if (!this.oid) { // dont'log!
            return false;
        }
        return (task && (task["definition"]["type"] === "UserTask") && (task["status"] === "READY" || task["status"] === "ACTIVE"));
    };

    /* Page state variables */

    /** @type {?number} */
    this.oid = null;

    /** @type {?string} */
    this.status = null;

    /** @type {?Object} */
    this.processDefinition = null;

    /** @type {!Object<string,Array<string>>} */
    this.catchingEventsByTaskId = {};

    /** @type {!Array<string>} */
    this.involvedUsers = [];

};

/**
 * @package
 * @const {string}
 */
ui.ctrl.ProcessDetails.VIEW_NAME = "processDetails";

/**
 * @package
 * @const {string}
 */
ui.ctrl.ProcessDetails.VIEW_PARAM = "processId";




//== ui/ctrl/Root.js ==========================================================

/**
 * @constructor
 * @ngInject
 * @param {!ui.AuthService} uiAuth
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.Root = function(uiAuth, uiAlerter, uiDialog, $rootScope, $location, $log) {

    /**
     * @return {!Promise}
     */
    this.logout = function() {
        return uiAuth.logout().then(function() {
            $log.debug("Logged out, redirecting to default path");
            uiAlerter.showInfo("You have been logged out");
            $location.path("/");
            ui.applyScope($rootScope);
        }.bind(this), function(e) {
            $log.debug("Logout failed");
            uiAlerter.showError(e.message);
        }.bind(this));
    };

    this._publishAuthStatus(uiAuth);

    /**
     * @param {number} userId
     * @return {boolean}
     */
    this.isCurrentUser = function(userId) {
        return uiAuth.isLoggedIn() && (userId === uiAuth.retrieveUserOid());
    };

    /**
     * @return {undefined}
     */
    this.uploadProcessArchive = function() {
        uiDialog.showDialog({
            templateUrl: "dialogs/newDeploy.html",
            controller: ui.ctrl.NewDeploy
        });
    }

};

/**
 * @private
 * @param {!ui.AuthService} uiAuth
 */
ui.ctrl.Root.prototype._publishAuthStatus = function(uiAuth) {
    Object.defineProperties(this, {
        "loggedIn": {
            get: uiAuth.isLoggedIn.bind(uiAuth)
        },
        "currentUsername": {
            get: uiAuth.retrieveCurrentUsername.bind(uiAuth)
        }
    });
};




//== ui/ctrl/UserCreation.js ==================================================

/**
 * @constructor
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.AlerterService} uiAlerter
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.UserCreation = function(uiBackEnd, uiAlerter, $rootScope, $location, $log) {

    /**
     * @return {!Promise}
     */
    this.createUser = function() {
        if (!this.username || !this.password) {
            $log.error("Missing");
            return Promise.resolve();
        }

        var data = {};
        if (this.email !== null) {
            data["email"] = this.email;
        }
        if (this.firstName !== null) {
            data["firstName"] = this.firstName;
        }
        if (this.lastName !== null) {
            data["lastName"] = this.lastName;
        }
        return uiBackEnd.createUser(this.username, this.password, data).then(function(result) {
            $log.debug("Created user");
            $location.path("userDetails/" + encodeURIComponent(String(result.oid)) + "/editUser");
            ui.applyScope($rootScope);
        }.bind(this), function(e) {
            $log.debug("Created user failed");
            uiAlerter.showError(e.message);
        }.bind(this));
    };

    /* Page state variables */

    /** @type {?string} */
    this.username = null;

    /** @type {?string} */
    this.password = null;

    /** @type {string} */
    this.confirmPassword = "";

    /** @type {?string} */
    this.email = null;

    /** @type {?string} */
    this.firstName = null;

    /** @type {?string} */
    this.lastName = null;

};

/**
 * @package
 * @const {string}
 */
ui.ctrl.UserCreation.VIEW_NAME = "userCreation";




//== ui/ctrl/UserDetails.js ===================================================

/**
 * @constructor
 * @ngInject
 * @param {!angular.$routeParams} $routeParams
 * @param {!ui.BackEndService} uiBackEnd
 * @param {!ui.StorageService} uiStorage
 * @param {!ui.AlerterService} uiAlerter
 * @param {!ui.DialogService} uiDialog
 * @param {!angular.Scope} $rootScope
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 */
ui.ctrl.UserDetails = function($routeParams, uiBackEnd, uiStorage, uiAlerter, uiDialog, $rootScope, $location, $log) {

    /**
     * @const {number}
     */
    this.userId = Number($routeParams["userId"]);

    /** @private */
    this._uiBackEnd = uiBackEnd;

    /** @private */
    this._uiStorage = uiStorage;

    /**
     * @param {!Object} user
     * @return {undefined}
     */
    this.prefillForm = function(user) {
        this.oid = user["oid"];
        this.username = user["username"];
        this.email = user["email"];
        this.firstName = user["firstName"];
        this.lastName = user["lastName"];
        user["roles"].sort(function(x, y) {
            var a = String(x).toUpperCase();
            var b = String(y).toUpperCase();
            if (a > b) {
                return 1
            }
            if (a < b) {
                return -1
            }
            return 0;
        });
        this.roles = user["roles"];// temp;
    };

    /**
     * @return {!Promise}
     */
    this.initializeController = function() {
        return uiBackEnd.listRoles(null).then(function(data) {
            var roleNames = {};// only for string!
            data.forEach(function(role) {
                roleNames[role["name"]] = true;
            }, this);
            var availableRoleNamesTemp = Object.keys(roleNames);
            availableRoleNamesTemp.sort(function(x, y) {
                var a = String(x).toUpperCase();
                var b = String(y).toUpperCase();
                if (a > b) {
                    return 1
                }
                if (a < b) {
                    return -1
                }
                return 0;
            });
            this.availableRoleNames = availableRoleNamesTemp;
        }.bind(this));
    };

    /**
     * @return {!Promise}
     */
    this.updateUser = function() {
        var data = {};
        if (this.email !== null) {
            data["email"] = this.email;
        }
        if (this.firstName !== null) {
            data["firstName"] = this.firstName;
        }
        if (this.lastName !== null) {
            data["lastName"] = this.lastName;
        }
        if (this.roles !== null) {
            data["roles"] = this.roles;
        }
        return this._uiBackEnd.updateUser(this.userId, data).then(function() {
            $log.debug("Updated user");
            $location.path("userDetails/" + encodeURIComponent(String(this.userId)) + "/userInfo");
            ui.applyScope($rootScope);
            $rootScope.$broadcast("uiDataFamilyUpdated", "users");
        }.bind(this), function(e) {
            $log.debug("Updated user failed");
            uiAlerter.showError(e.message);
        }.bind(this));
    };

    /**
     * @return {!Promise}
     */
    this.deleteUser = function() {
        return uiDialog.showDangerConfirm("Are you sure?", [ "Delete", "Cancel" ]).then(function(index) {
            if (index !== 0) {
                return;
            }
            return this._uiBackEnd.deleteUser(this.userId).then(function() {
                $log.debug("Deleted user");
                $location.path("users");
                ui.applyScope($rootScope);
            }.bind(this), function(e) {
                $log.debug("Deleted user failed");
                uiAlerter.showError(e.message);
            }.bind(this));
        }.bind(this))
    }

    /**
     * @return {undefined}
     */
    this.changePassword = function() {
        uiDialog.showDialog({
            templateUrl: "dialogs/changePassword.html",
            controller: ui.ctrl.ChangePassword,
            data: {
                "userId": this.userId
            }
        });
    };

    this.initializeController();

    /* Page state variables */

    /** @type {?number} */
    this.oid = null;

    /** @type {?string} */
    this.username = null;

    /** @type {?string} */
    this.email = null;

    /** @type {?string} */
    this.firstName = null;

    /** @type {?string} */
    this.lastName = null;

    /** @type {!Array} */
    this.roles = [];

    /** @type {!Array} */
    this.availableRoleNames = [];

};

/**
 * @package
 * @const {string}
 */
ui.ctrl.UserDetails.VIEW_NAME = "userDetails";

/**
 * @package
 * @const {string}
 */
ui.ctrl.UserDetails.VIEW_PARAM = "userId";




//== ui/ctrl/_ctrl.js =========================================================

/**
 * @name ui.ctrl
 * @namespace
 */

/**
 * @internal
 * @return {!Array<string>}
 */
ui.ctrl.getViewNames = function() {
    return Object.keys(ui.ctrl._getViewsMap());
};

/**
 * @internal
 * @typedef {{name:string, paramName:(string|undefined), controller:function(?)}}
 */
ui.ctrl.ViewConfig;

/**
 * @internal
 * @param {string} viewName
 * @return {!ui.ctrl.ViewConfig}
 */
ui.ctrl.getView = function(viewName) {
    var ctor = ui.ctrl._getViewsMap()[viewName];
    if (!ctor) {
        throw new Error("No controller for view '" + viewName + "'");
    }
    return ctor;
};

/**
 * @private
 * @type {?Object<string,!ui.ctrl.ViewConfig>}
 */
ui.ctrl._map = null;

/**
 * @internal
 * @return {!Object<string,!ui.ctrl.ViewConfig>}
 */
ui.ctrl._getViewsMap = function() {
    if (ui.ctrl._map) {
        return ui.ctrl._map;
    }

    /* Construct the map anew */
    var map = {};
    Object.keys(ui.ctrl).forEach(function(ctorName) {
        var ctor = ui.ctrl[ctorName];
        if (typeof ctor !== "function") {
            return; // continue
        }
        var viewName = ctor["VIEW_NAME"];
        var viewParamName = ctor["VIEW_PARAM"];
        if (viewName) {
            map[viewName] = {
                name: viewName,
                paramName: viewParamName,
                controller: ctor
            };
        }
    });
    ui.ctrl._map = map; // cache

    return map;
};




//== ui/DialogService.js ======================================================

/**
 * @constructor
 * @ngInject
 * @param {?} $uibModal
 * @param {!angular.Scope} $rootScope
 */
ui.DialogService = function($uibModal, $rootScope) {

    /** @private */
    this._uiModal = $uibModal;

    /** @private */
    this._$rootScope = $rootScope;
}

/**
 * @param {string} message
 * @param {!Array<string>=} buttons
 * @return {!Promise<number>}
 */
ui.DialogService.prototype.showInfoConfirm = function(message, buttons) {
    return this.showConfirm(message, this._normalizeConfirmButtons(buttons, false));
};

/**
 * @param {string} message
 * @param {!Array<string>=} buttons
 * @return {!Promise<number>}
 */
ui.DialogService.prototype.showDangerConfirm = function(message, buttons) {
    return this.showConfirm(message, this._normalizeConfirmButtons(buttons, true));
};

/**
 * @param {string} message
 * @param {!Array<{label:string, primary:(boolean|undefined), danger:(boolean|undefined)}>} buttons
 * @return {!Promise<number>}
 */
ui.DialogService.prototype.showConfirm = function(message, buttons) {
    return this.showDialog({
        templateUrl: "dialogs/confirm.html",
        data: {
            "message": message,
            "buttons": buttons
        }
    }).then(function(result) {
        if (result.dismissed) {
            return -1;
        }
        return result.value["index"];
    });
};

/**
 * @private
 * @param {!Array<string|{label:string, primary:(boolean|undefined), danger:(boolean|undefined)}>|undefined} buttons
 * @param {boolean} dangerDefault
 * @return {!Array<{label:string, primary:(boolean|undefined), danger:(boolean|undefined)}>}
 */
ui.DialogService.prototype._normalizeConfirmButtons = function(buttons, dangerDefault) {

    /* Default buttons in case none was passed */
    buttons = buttons || [ "Yes", "No" ];

    /* Change into full objects */
    var defaultFound = false;
    buttons = buttons.map(function(btn, index) {
        var buttonObject;
        if (typeof btn === "string") {
            return {
                "index": index,
                "label": btn
            };
        } else {
            if (btn.primary || btn.danger) {
                defaultFound = true;
            }
            return {
                "index": index,
                "label": btn.label,
                "primary": btn.primary,
                "danger": btn.danger
            };
        }
    });

    /* Make the first primary if not explicitly set */
    if (!defaultFound) {
        buttons[0][dangerDefault ? "danger" : "primary"] = true;
    }

    return buttons;
};

/*
 * Generic dialogs
 */

/**
 * @template T
 * @param {{templateUrl:string, controller:(function(new:ui.ctrl.Dialog<T>)|undefined), data:(!Object|undefined)}} options
 * @return {!Promise<{value:T, dismissed:boolean}>}
 */
ui.DialogService.prototype.showDialog = function(options) {

    /* Create a dialog scope with the initial data */
    var dialogScope;
    if (options.data) {
        dialogScope = this._$rootScope.$new(false);
        angular.extend(dialogScope, options.data);
    } else {
        dialogScope = undefined;
    }

    var modal = this._uiModal["open"]({
        "templateUrl": options.templateUrl,
        "controller": options.controller || ui.ctrl.Dialog,
        "controllerAs": "ctrl",
        "scope": dialogScope
    });
    return modal["result"].then(function(result) {
        return {
            value: result,
            dismissed: false
        };
    }, function() {
        return {
            value: undefined,
            dismissed: true
        };
    });
};



//== ui/dir/clickDecorator.js =================================================

/**
 * @ngInject
 * @param {!Array<!angular.Directive>} $delegate
 * @param {!ui.ActivityService} uiActivity
 * @return {!Array<!angular.Directive>}
 */
ui.dir.clickDecorator = function($delegate, uiActivity) {
    return $delegate.map(function(original) {
        return angular.extend({}, original, {
            scope: true,

            /**
             * @param {!angular.JQLite} element
             * @param {!angular.Attributes} attrs
             */
            compile: function(element, attrs) {
                var useLoading = (attrs["uiShowLoading"] !== undefined);

                attrs["ngClick"] = "_interceptLoading(" + attrs["ngClick"] + ")";
                var originalLink = original.compile.apply(this, arguments);

                /* Function for beginning the loading experience */
                function beginLoading() {
                    uiActivity.startActivity();
                    if (!useLoading) {
                        element["button"]("loading");
                    }
                }

                /* Function for finishing the loading experience */
                function finishLoading() {
                    if (!useLoading) {
                        element["button"]("reset");
                    }
                    uiActivity.stopActivity();
                }

                /**
                 * @param {!angular.Scope} scope
                 * @param {!angular.JQLite} element
                 * @param {!angular.Attributes} attrs
                 */
                function link(scope, element, attrs) {
                    scope["_interceptLoading"] = function(result) {
                        if (ui.isPromise(result)) {
                            beginLoading();
                            return Promise.resolve(result).then(function(r) {
                                finishLoading();
                                return r;
                            }, function(e) {
                                finishLoading();
                                throw e;
                            });
                        }
                        return result;
                    };
                    return originalLink.apply(this, arguments);
                }

                return link;
            }

        });
    });
};



//== ui/AppConfig.js ==========================================================

/**
 * @package
 * @const
 */
ui.AppConfig = {};

/**
 * @ngInject
 * @param {!angular.$routeProvider} $routeProvider
 */
ui.AppConfig.configureRouting = function($routeProvider) {
    ui.Router.configure($routeProvider);
};

/**
 * @ngInject
 * @param {!angular.$provide} $provide
 */
ui.AppConfig.decorateDirectives = function($provide) {
    $provide.decorator("ngClickDirective", ui.dir.clickDecorator);
};



//== ui/dir/historicProcessAttachmentListDirective.js =========================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.historicProcessAttachmentListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiHistoricProcessAttachmentList",
        variable: "historicProcessAttachmentList",
        fetchData: function(processId, query) {
            return uiBackEnd.listHistoricProcessAttachments(processId, query);
        }
    });
};



//== ui/dir/historicProcessByDefinitionListDirective.js =======================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.historicProcessByDefinitionListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiHistoricProcessByDefinitionList",
        variable: "historicProcessList",
        fetchData: function(definitionId, query) {
            var definitionIdTerm = new rest.data.filter.Term(rest.data.filter.Operator.EQUAL,
                    rest.data.Ref.parse("processDefinition.definitionId"), definitionId);
            if (query) {
                return uiBackEnd.listHistoricProcesses(new rest.data.Query(definitionIdTerm, query.getSorting(), query.getPaging()));
            } else {
                return uiBackEnd.listProcesses(new rest.data.Query(definitionIdTerm, [], null));
            }
        }
    });
};



//== ui/dir/historicProcessDetailsDirective.js ================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.historicProcessDetailsDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiHistoricProcessDetails",
        variable: "historicProcessDetails",
        fetchData: function(historicProcessId) {
            return uiBackEnd.retrieveHistoricProcess(historicProcessId);
        },
        dataFamilies: [ "processes" ],
        converters: {

            "createdAt": ui.dir.TIMESTAMP_CONVERTER,

            "updatedAt": ui.dir.TIMESTAMP_CONVERTER,

        }
    });
};



//== ui/dir/historicProcessDiagramDirective.js ================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.historicProcessDiagramDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiHistoricProcessDiagram",
        variable: "historicProcessDiagram",
        fetchData: function(parentId, query) {
            return uiBackEnd.retrieveHistoricProcessDiagramId(parentId).then(function(diagramId) {
                return uiBackEnd.downloadFile(diagramId);
            });
        }
    });
};



//== ui/dir/historicProcessListDirective.js ===================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.historicProcessListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiHistoricProcessList",
        variable: "historicProcessList",
        fetchData: function(parentId, query) {
            return uiBackEnd.listHistoricProcesses(query);
        },
        references: {
            "parameterValues": new rest.data.PathRef("historicParameters", "value"),
            "ownerRoleName": new rest.data.PathRef("historicTasks", "role"),
            "processDefinitionName": new rest.data.PathRef("processDefinition", "name"),
            "ownerUserName": new rest.data.PathRef("historicTasks", "user")
        }
    });
};



//== ui/dir/historicProcessNoteListDirective.js ===============================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.historicProcessNoteListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiHistoricProcessNoteList",
        variable: "historicProcessNoteList",
        fetchData: function(processId, query) {
            return uiBackEnd.listHistoricProcessNotes(processId, query);
        }
    });
};



//== ui/dir/historicProcessTaskListDirective.js ===============================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.historicProcessTaskListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiHistoricProcessTaskList",
        variable: "historicProcessTaskList",
        fetchData: function(historicProcessId, query) {
            return uiBackEnd.listHistoricProcessTasks(historicProcessId, query);
        },
        trackingProperty: "oid"
    });
};



//== ui/dir/localListDirective.js =============================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.localListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiLocalList",
        variable: "localList",
        fetchData: function(inputData, query) {
            return new rest.data.Processor(inputData).query(query);
        },
        dataFamilies: [ "foo" ]
    });
};



//== ui/dir/processArchiveListDirective.js ====================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processArchiveListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessArchiveList",
        variable: "processArchiveList",
        fetchData: function(parentId, query) {
            return uiBackEnd.listProcessArchives(query);
        },
        dataFamilies: [ "processArchives" ]
    });
};



//== ui/dir/processAttachmentListDirective.js =================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processAttachmentListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessAttachmentList",
        variable: "processAttachmentList",
        fetchData: function(processId, query) {
            return uiBackEnd.listProcessAttachments(processId, query);
        }
    });
};



//== ui/dir/processByDefinitionListDirective.js ===============================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processByDefinitionListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessByDefinitionList",
        variable: "processByDefList",
        fetchData: function(definitionId, query) {
            var definitionIdTerm = new rest.data.filter.Term(rest.data.filter.Operator.EQUAL,
                    rest.data.Ref.parse("processDefinition.definitionId"), definitionId);
            if (query) {
                return uiBackEnd.listProcesses(new rest.data.Query(definitionIdTerm, query.getSorting(), query.getPaging()));
            } else {
                return uiBackEnd.listProcesses(new rest.data.Query(definitionIdTerm, [], null));
            }
        }
    });
};



//== ui/dir/processDefinitionDetailsDirective.js ==============================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processDefinitionDetailsDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessDefinitionDetails",
        variable: "processDefinitionDetails",
        fetchData: function(processDefinitionId) {
            return uiBackEnd.retrieveProcessDefinition(processDefinitionId);
        },
        dataFamilies: [ "processDefinitions" ]
    });
};



//== ui/dir/processDefinitionDiagramDirective.js ==============================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processDefinitionDiagramDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessDefinitionDiagram",
        variable: "processDefinitionDiagram",
        fetchData: function(parentId, query) {
            return uiBackEnd.retrieveProcessDefinitionDiagramId(parentId).then(function(diagramId) {
                return uiBackEnd.downloadFile(diagramId);
            });
        }
    });
};



//== ui/dir/processDefinitionListDirective.js =================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processDefinitionListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessDefinitionList",
        variable: "processDefinitionList",
        fetchData: function(parentId, query) {
            return uiBackEnd.listProcessDefinitions(query);
        }
    });
};



//== ui/dir/processDetailsDirective.js ========================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processDetailsDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessDetails",
        variable: "processDetails",
        fetchData: function(processId) {
            return uiBackEnd.retrieveProcess(processId);
        },
        dataFamilies: [ "processes" ],
        converters: {

            "createdAt": ui.dir.TIMESTAMP_CONVERTER,

            "updatedAt": ui.dir.TIMESTAMP_CONVERTER,

        }
    });
};



//== ui/dir/processDiagramDirective.js ========================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processDiagramDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessDiagram",
        variable: "processDiagram",
        fetchData: function(parentId, query) {
            return uiBackEnd.retrieveProcessDiagramId(parentId).then(function(diagramId) {
                return uiBackEnd.downloadFile(diagramId);
            });
        }
    });
};



//== ui/dir/processListDirective.js ===========================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessList",
        variable: "processList",
        fetchData: function(parentId, query) {
            return uiBackEnd.listProcesses(query);
        },
        references: {
            "parameterValues": new rest.data.PathRef("parameters", "value"),
            "ownerRoleName": new rest.data.PathRef("tasks", "ownerRole", "roleName"),
            "processDefinitionName": new rest.data.PathRef("processDefinition", "name"),
            "ownerUserName": new rest.data.PathRef("tasks", "ownerUser", "username")
        }
    });
};



//== ui/dir/processNoteListDirective.js =======================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processNoteListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessNoteList",
        variable: "processNoteList",
        fetchData: function(processId, query) {
            return uiBackEnd.listProcessNotes(processId, query);
        }
    });
};



//== ui/dir/processTaskListDirective.js =======================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processTaskListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessTaskList",
        variable: "processTaskList",
        fetchData: function(processId, query) {
            if (processId === undefined) {
                return uiBackEnd.listProcesses(null).then(function(processes) {
                    var allTasks = [];
                    return processes.reduce(function(chain, process) {
                        return chain.then(function() {
                            return uiBackEnd.listProcessTasks(process["oid"], null);
                        }).then(function(tasks) {
                            Array.prototype.push.apply(allTasks, tasks);
                        });
                    }, Promise.resolve()).then(function() {
                        return new rest.data.Processor(allTasks).query(query);
                    });
                });
            }
            return uiBackEnd.listProcessTasks(processId, query);
        },
        trackingProperty: "oid"
    });
};



//== ui/dir/processVersionListDirective.js ====================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.processVersionListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiProcessVersionList",
        variable: "processVersionList",
        fetchData: function(definitionId, query) {
            var definitionIdTerm = new rest.data.filter.Term(rest.data.filter.Operator.EQUAL, rest.data.Ref.parse("modelId"),
                    definitionId);
            if (query) {
                // TODO merge query filters if any
                return uiBackEnd.listProcessDefinitions(new rest.data.Query(definitionIdTerm, query.getSorting(), query.getPaging()));
            } else {
                return uiBackEnd.listProcessDefinitions(new rest.data.Query(definitionIdTerm, [], null));
            }
        }
    });
};



//== ui/dir/roleListDirective.js ==============================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.roleListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiRoleList",
        variable: "roleList",
        fetchData: function(parentId, query) {
            return uiBackEnd.listRoles(query);
        }
    });
};



//== ui/dir/taskCandidateRoleListDirective.js =================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.taskCandidateRoleListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiTaskCandidateRoleList",
        variable: "taskCandidateRoleList",
        fetchData: function(taskId, query) {
            return uiBackEnd.retrieveTaskCandidateRoles(taskId, query);
        }
    });
};



//== ui/dir/taskCandidateUserListDirective.js =================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.taskCandidateUserListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiTaskCandidateUserList",
        variable: "taskCandidateUserList",
        fetchData: function(taskId, query) {
            return uiBackEnd.retrieveTaskCandidateUsers(taskId, query);
        }
    });
};



//== ui/dir/userDetailsDirective.js ===========================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.userDetailsDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiUserDetails",
        variable: "userDetails",
        fetchData: function(userId) {
            return uiBackEnd.retrieveUser(userId);
        },
        dataFamilies: [ "users" ]
    });
};



//== ui/dir/userListDirective.js ==============================================

/**
 * @ngInject
 * @param {!ui.BackEndService} uiBackEnd
 * @return {!angular.Directive}
 */
ui.dir.userListDirective = function(uiBackEnd) {
    return ui.cmp.dataViewDirectiveFactory({
        directiveName: "uiUserList",
        variable: "userList",
        fetchData: function(parentId, query) {
            return uiBackEnd.listUsers(query);
        },
        dataFamilies: [ "users" ],
        references: {
            "roleNames": new rest.data.PathRef("roles", "roleName")
        }
    });
};



//== ui/App.js ================================================================

/**
 * @type {!angular.Module}
 */
ui.App = (function() {
    var module = angular.module("wrAdminUi", [ "ngRoute", "ui.bootstrap", "angularMoment" ]);

    /* Configuration functions */
    angular.forEach(ui.AppConfig, function(configFunction) {
        module.config(configFunction);
    });

    /* Run functions */
    angular.forEach(ui.AppRun, function(runFunction) {
        module.run(runFunction);
    });

    /* Directives */
    module.directive("input", ui.cmp.inputFileDirective);
    module.directive("uiActivityIndicator", ui.cmp.activityIndicator);
    module.directive("uiBlob", ui.cmp.blobDirective);
    module.directive("uiErrorMessage", ui.cmp.errorMessageDirective);
    module.directive("uiFilter", ui.cmp.filterDirective);
    module.directive("uiHistoricProcessByDefinitionList", ui.dir.historicProcessByDefinitionListDirective);
    module.directive("uiHistoricProcessList", ui.dir.historicProcessListDirective);
    module.directive("uiHistoricProcessAttachmentList", ui.dir.historicProcessAttachmentListDirective);
    module.directive("uiHistoricProcessDetails", ui.dir.historicProcessDetailsDirective);
    module.directive("uiHistoricProcessTaskList", ui.dir.historicProcessTaskListDirective);
    module.directive("uiHistoricProcessNoteList", ui.dir.historicProcessNoteListDirective);
    module.directive("uiHistoricProcessDiagram", ui.dir.historicProcessDiagramDirective);
    module.directive("uiLocalList", ui.dir.localListDirective);
    module.directive("uiOneDayIncreaser", ui.cmp.oneDayIncreaserDirective);
    module.directive("uiProcessArchiveList", ui.dir.processArchiveListDirective);
    module.directive("uiProcessByDefinitionList", ui.dir.processByDefinitionListDirective);
    module.directive("uiProcessDefinitionDetails", ui.dir.processDefinitionDetailsDirective);
    module.directive("uiProcessDetails", ui.dir.processDetailsDirective);
    module.directive("uiProcessDefinitionDiagram", ui.dir.processDefinitionDiagramDirective);
    module.directive("uiProcessDiagram", ui.dir.processDiagramDirective);
    module.directive("uiProcessAttachmentList", ui.dir.processAttachmentListDirective);
    module.directive("uiProcessDefinitionList", ui.dir.processDefinitionListDirective);
    module.directive("uiProcessList", ui.dir.processListDirective);
    module.directive("uiProcessNoteList", ui.dir.processNoteListDirective);
    module.directive("uiProcessTaskList", ui.dir.processTaskListDirective);
    module.directive("uiProcessVersionList", ui.dir.processVersionListDirective);
    module.directive("uiRoleList", ui.dir.roleListDirective);
    module.directive("uiScroller", ui.cmp.scrollerDirective);
    module.directive("uiSorter", ui.cmp.sorterDirective);
    module.directive("uiSorterProperty", ui.cmp.sorterPropertyDirective);
    module.directive("uiShowActive", ui.dir.showActiveDirective);
    module.directive("uiTabs", ui.cmp.tabsDirective);
    module.directive("uiTabsPane", ui.cmp.tabsPaneDirective);
    module.directive("uiTabsTab", ui.cmp.tabsTabDirective);
    module.directive("uiTaskCandidateRoleList", ui.dir.taskCandidateRoleListDirective);
    module.directive("uiTaskCandidateUserList", ui.dir.taskCandidateUserListDirective);
    module.directive("uiUserDetails", ui.dir.userDetailsDirective);
    module.directive("uiUserList", ui.dir.userListDirective);
    module.directive("uiValidateEqual", ui.cmp.validateEqualDirective);

    /* Filters */
    module.filter("uiUrlEscape", ui.urlEscapeFilter);
    module.filter("uiLocalize", ui.localizeFilter);

    /* Controllers */
    module.controller("uiRootController", ui.ctrl.Root);
    ui.ctrl.getViewNames().forEach(function(viewName) {
        module.controller("uiViewController." + viewName, ui.ctrl.getView(viewName).controller);
    });

    /* Services */
    module.service("uiActivity", ui.ActivityService);
    module.service("uiAlerter", ui.AlerterService);
    module.service("uiAuth", ui.AuthService);
    module.service("uiBackEnd", ui.BackEndService);
    module.service("uiConfig", ui.ConfigService);
    module.service("uiDialog", ui.DialogService);
    module.service("uiStorage", ui.StorageService);

    return module;
})();




//== ui/Router.js =============================================================

/**
 * @package
 * @const
 */
ui.Router = {};

/**
 * @param {!angular.$routeProvider} $routeProvider
 */
ui.Router.configure = function($routeProvider) {

    /* Create a route for each of the views */
    ui.ctrl.getViewNames().forEach(function(viewName) {
        var view = ui.ctrl.getView(viewName);
        var routeConfig = {
            templateUrl: function(params) {
                return "views/" + viewName + ".html";
            },
            resolve: (viewName !== "test" ? {
                "checkNotLoggedIn": ui.Router._checkNotLoggedIn
            } : {}),
            controller: view.controller,
            controllerAs: "ctrl"
        };
        $routeProvider.when("/" + viewName + (view.paramName ? "/:" + view.paramName : ""), routeConfig);
        $routeProvider.when("/" + viewName + (view.paramName ? "/:" + view.paramName : "") + "/:internalPath*", routeConfig);
    });

    /* Special route for logging in */
    $routeProvider.when("/login", {
        templateUrl: "login.html",
        resolve: {
            "nextPath": ui.Router._checkLoggedIn
        },
        controller: ui.ctrl.Login,
        controllerAs: "ctrl"
    });

    /* Use the home as default route */
    $routeProvider.when("/", {
        redirectTo: "/home"
    });

    /* Redirect non-configured routes to an error page */
    $routeProvider.otherwise({
        templateUrl: "notfound.html"
    });
};

/**
 * @ngInject
 * @param {!ui.AuthService} uiAuth
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 * @return {string|undefined}
 */
ui.Router._checkLoggedIn = function(uiAuth, $location, $log) {
    if (!uiAuth.isLoggedIn()) {
        return ui.Router._lastNonLoginDestination;
    }

    $log.debug("Already logged in, redirecting to home");
    $location.path("/home");
}

/**
 * @ngInject
 * @param {!ui.AuthService} uiAuth
 * @param {!angular.$location} $location
 * @param {!angular.$log} $log
 * @return {undefined}
 */
ui.Router._checkNotLoggedIn = function(uiAuth, $location, $log) {
    if (uiAuth.isLoggedIn()) {
        return;
    }

    $log.debug("Not logged in, redirecting");

    /* Reach the attempted path only if it was not the login */
    var currentPath = /** @type {string} */
    ($location.path());
    if (currentPath === "/login" || currentPath === "/home") {
        ui.Router._lastNonLoginDestination = "";
    } else {
        ui.Router._lastNonLoginDestination = currentPath;
    }

    $location.path("/login");
};

/**
 * @private
 * @type {string}
 */
ui.Router._lastNonLoginDestination = "";

/*
 * Internal path management
 */

/**
 * @param {!angular.$route} $route
 * @param {!angular.Scope} $rootScope
 */
ui.Router.startMonitoringInternalPath = function($route, $rootScope) {
    var lastRoute = $route.current;
    $rootScope.$on("$locationChangeSuccess", function(event) {
        var internalPath = $route.current && $route.current.pathParams["internalPath"];
        var lastInternalPath = lastRoute && lastRoute.pathParams["internalPath"];

        if (ui.Router._isChangedRoute($route.current, lastRoute)) {
            lastRoute = $route.current;
            ui.Router._raiseInternalPathChanged($rootScope, internalPath);
            return;
        }
        $route.current = lastRoute; // suppress the change

        if (internalPath !== lastInternalPath) {
            $route.current.pathParams["internalPath"] = internalPath;
            ui.Router._raiseInternalPathChanged($rootScope, internalPath);
        }
    });
};

/**
 * @param {!angular.Scope} $rootScope
 * @param {string} internalPath
 */
ui.Router._raiseInternalPathChanged = function($rootScope, internalPath) {
    $rootScope.$broadcast("uiInternalPathChanged", internalPath || null);
};

/**
 * @private
 * @param {?angular.$route.Route} route
 * @param {?angular.$route.Route} lastRoute
 * @return {boolean}
 */
ui.Router._isChangedRoute = function(route, lastRoute) {

    /* Compare the normalized route pattern (ignoring internal path) */
    var INTERNAL_PATH_PATTERN = /\/:internalPath\*$/;
    var pattern = ui.Router._getRoutePattern(route, INTERNAL_PATH_PATTERN);
    var lastPattern = ui.Router._getRoutePattern(lastRoute, INTERNAL_PATH_PATTERN);
    if (!route || lastPattern !== pattern) {
        return true;
    }

    /* Compare parameters (ignoring internal path) */
    var params, lastParams;
    if (route["$$route"].reloadOnSearch) {
        params = route.params;
        lastParams = lastRoute.params;
    } else {
        params = route.pathParams;
        lastParams = lastRoute.pathParams;
    }
    return ui.Router._haveDifferentValues(params || {}, lastParams || {}, "internalPath");
}

/**
 * @param {?angular.$route.Route} route
 * @param {!RegExp=} ignoreRegexp
 * @return {?string}
 */
ui.Router._getRoutePattern = function(route, ignoreRegexp) {
    if (!route) {
        return null;
    }
    var pattern = route["$$route"].originalPath;
    return ignoreRegexp ? pattern.replace(ignoreRegexp, "") : pattern;
}

/**
 * @private
 * @param {!Object<string,string>} obj1
 * @param {!Object<string,string>} obj2
 * @param {string=} ignoredKey
 * @return {boolean}
 */
ui.Router._haveDifferentValues = function(obj1, obj2, ignoredKey) {
    var checkedKeys = {};
    if (ignoredKey) {
        checkedKeys[ignoredKey] = true;
    }
    for (var key in obj1) {
        if (obj1.hasOwnProperty(key) && !checkedKeys[key]) {
            checkedKeys[key] = true;
            if (obj1[key] !== obj2[key]) {
                return true;
            }
        }
    }
    for (var key in obj2) {
        if (obj2.hasOwnProperty(key) && !checkedKeys[key]) {
            checkedKeys[key] = true;
            if (obj1[key] !== obj2[key]) {
                return true;
            }
        }
    }
    return false;
}

exportSymbol("ui", ui);


})();})(this);