/**
 * 
 */
package net.sf.jasperreports.components.charts;

import java.io.Serializable;

import net.sf.jasperreports.engine.JRElementDataset;

/**
 *
 * @author sanda zaharia (shertage@users.sourceforge.net)
 * @version $Id: ChartDataset.java 3936 2010-08-13 15:34:10Z shertage $
 */
public interface ChartDataset extends JRElementDataset, Serializable
{

}
