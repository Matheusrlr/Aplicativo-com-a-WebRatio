### 4.0.1 (Dec 27, 2017)
* CB-13701Fix to allow 4.0.0 version install

