package com.webratio.accountmanager;

public interface Constants {

	public static String PREFS_NAME = "LoginPrefs";
}
