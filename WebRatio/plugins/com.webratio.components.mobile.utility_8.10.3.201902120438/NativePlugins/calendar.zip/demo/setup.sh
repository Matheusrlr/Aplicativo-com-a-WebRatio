cordova platform add android
cordova platform add ios
cordova plugin add https://github.com/EddyVerbruggen/Calendar-PhoneGap-Plugin
